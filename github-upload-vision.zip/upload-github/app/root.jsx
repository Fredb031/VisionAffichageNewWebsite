import {useNonce} from '@shopify/hydrogen';
import {
  Outlet,
  Links,
  Meta,
  Scripts,
  ScrollRestoration,
  isRouteErrorResponse,
  useRouteError,
} from 'react-router';
import globalsHref from '~/styles/globals.css?url';

export function links() {
  return [
    {rel: 'preconnect', href: 'https://fonts.googleapis.com'},
    {rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous'},
    {
      rel: 'stylesheet',
      href: 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap',
    },
    {rel: 'stylesheet', href: globalsHref},
  ];
}

export function meta() {
  return [
    {title: "Vision Affichage · Ton linge d'entreprise, livré en 5 jours ouvrables"},
    {
      name: 'description',
      content:
        "Importe ton logo, choisis tes vêtements, reçois ton linge d'entreprise personnalisé en 5 jours ouvrables.",
    },
  ];
}

export function Layout({children}) {
  const nonce = useNonce();
  return (
    <html lang="fr">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>
      <body>
        {children}
        <ScrollRestoration nonce={nonce} />
        <Scripts nonce={nonce} />
      </body>
    </html>
  );
}

export default function App() {
  return <Outlet />;
}

export function ErrorBoundary() {
  const error = useRouteError();
  let message = 'Une erreur est survenue.';
  let status = 500;
  if (isRouteErrorResponse(error)) {
    status = error.status;
    message = error.status === 404 ? "Cette page n'existe pas." : message;
  }
  return (
    <main
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '12px',
        fontFamily: 'Manrope, system-ui, sans-serif',
        background: '#f5f6f5',
        color: '#0b0f0d',
      }}
    >
      <h1 style={{fontSize: '2rem', fontWeight: 800}}>{status}</h1>
      <p>{message}</p>
      <a href="/" style={{color: '#059455', fontWeight: 700}}>
        Retour à l'accueil
      </a>
    </main>
  );
}
