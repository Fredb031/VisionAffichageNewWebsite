

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence, MotionConfig, useReducedMotion } from "framer-motion";
import LogoOverlayImage from "./LogoOverlayImage";
import { colorHex, isLight } from "~/lib/colors";
import {
  sizesFor, unitPrice, supportsBack, isPack, isAccessory, fmt,
  positionsFor, smartColors,
  LOGO_FRONT_PRICE, LOGO_BACK_PRICE,
} from "~/lib/catalog";

// Sélectionne tout le contenu du champ quantité au focus (clic ou Tab),
// sans empêcher de replacer le curseur aux clics suivants.
const selectAllProps = {
  onFocus: (e) => e.target.select(),
  onMouseDown: (e) => {
    if (document.activeElement !== e.target) e.target.dataset.selecting = "1";
  },
  onMouseUp: (e) => {
    if (e.target.dataset.selecting) {
      delete e.target.dataset.selecting;
      e.preventDefault();
    }
  },
};

// Ressorts partagés : fermes et naturels, sans rebond excessif.
// Tout roule sur transform/opacity (60 fps), et MotionConfig reducedMotion="user"
// respecte automatiquement la préférence système « réduire les animations ».
const SPRING_MODAL = { type: "spring", stiffness: 400, damping: 34, mass: 0.9 };
const SPRING_LAYOUT = { type: "spring", stiffness: 460, damping: 38 };
const SPRING_POP = { type: "spring", stiffness: 620, damping: 24 };

// Apparition/disparition des panneaux de réglages (réorganisation sans saut :
// la sortie est un fondu très court, les voisins glissent via layout)
const blockVariants = {
  initial: { opacity: 0, y: -5 },
  animate: { opacity: 1, y: 0, transition: SPRING_LAYOUT },
  exit: { opacity: 0, transition: { duration: 0.1 } },
};

// Bornes du slider de taille du logo (servent aussi à placer la bulle sous le pouce)
const SCALE_MIN = 0.6;
const SCALE_MAX = 1.5;

// Variants de l'aperçu : glissement directionnel entre devant/dos,
// fondu doux entre couleurs (dir = 0)
const previewVariants = {
  enter: (dir) => ({ opacity: 0, x: dir, scale: dir ? 1 : 0.985 }),
  center: { opacity: 1, x: 0, scale: 1 },
  exit: (dir) => ({ opacity: 0, x: dir ? -dir * 0.6 : 0, scale: dir ? 1 : 0.99 }),
};

export default function ProductModal({ product, logo, logoTone = "color", onClose, onAdd }) {
  const pack = isPack(product);
  const accessory = isAccessory(product);
  const sizes = sizesFor(product);
  const positions = positionsFor(product);
  const canBack = supportsBack(product);
  const prefersReduced = useReducedMotion();

  // Couleurs réordonnées selon la teinte du logo (contraste parfait, rien de caché)
  const orderedColors = useMemo(() => smartColors(product, logoTone), [product, logoTone]);

  const [selectedColors, setSelectedColors] = useState([orderedColors[0]]);
  const [previewColor, setPreviewColor] = useState(orderedColors[0]);
  const [qty, setQty] = useState({}); // { couleur: { taille: n } }
  const [side, setSide] = useState(pack ? "inclus" : "front");
  const [position, setPosition] = useState(accessory ? "centre" : "coeur-gauche");
  // Taille du logo SÉPARÉE devant / dos — même gabarit pour toutes les couleurs
  const [scales, setScales] = useState({ front: 1, back: 1 });
  const [view, setView] = useState("front");
  const [showProofNotice, setShowProofNotice] = useState(false);
  const [added, setAdded] = useState(false);

  // Fermeture pilotée à l'interne : l'animation de sortie joue d'abord,
  // puis onClose est appelé (onExitComplete) pour démonter le modal.
  const [open, setOpen] = useState(true);
  const requestClose = useCallback(() => setOpen(false), []);

  // Bulle de pourcentage pendant le drag du slider
  const [sliderActive, setSliderActive] = useState(false);
  const bubbleTimer = useRef(null);
  const showBubble = () => {
    clearTimeout(bubbleTimer.current);
    setSliderActive(true);
  };
  const hideBubbleSoon = (delay = 450) => {
    clearTimeout(bubbleTimer.current);
    bubbleTimer.current = setTimeout(() => setSliderActive(false), delay);
  };

  const overlayRef = useRef(null);
  const closeTimer = useRef(null);

  const front = side === "front" || side === "both" || pack;
  const back = side === "back" || side === "both";
  const activeView = view === "back" && back ? "back" : "front";

  // Direction du glissement : seulement quand la FACE change (pas la couleur)
  const prevViewRef = useRef(activeView);
  const slide = prevViewRef.current !== activeView ? (activeView === "back" ? 26 : -26) : 0;
  useEffect(() => { prevViewRef.current = activeView; }, [activeView]);

  // Position de la bulle : suit le pouce du slider (fraction de la course,
  // corrigée de la demi-largeur du pouce natif, environ 16 px)
  const scaleFrac = (scales[activeView] - SCALE_MIN) / (SCALE_MAX - SCALE_MIN);
  const bubbleLeft = `calc(${(scaleFrac * 100).toFixed(2)}% + ${((0.5 - scaleFrac) * 16).toFixed(1)}px)`;

  // Variations du logo (compte ou invité) : choix par face, même gabarit pour toutes les couleurs
  const [logoLib, setLogoLib] = useState([]);
  const [faceLogo, setFaceLogo] = useState({ front: 0, back: 0 });
  useEffect(() => {
    try {
      const lib = JSON.parse(localStorage.getItem("va_logos") || "[]");
      if (Array.isArray(lib) && lib.length) setLogoLib(lib);
    } catch {}
  }, []);
  const activeLogo = logoLib[faceLogo[activeView]]?.data || logo;

  // Escape ferme (la pop-up d'abord, sinon le modal) + focus trap léger sur Tab
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        if (showProofNotice) setShowProofNotice(false);
        else requestClose();
        return;
      }
      if (e.key !== "Tab") return;
      const root = overlayRef.current;
      if (!root) return;
      const focusables = Array.from(
        root.querySelectorAll('button:not([disabled]), input, select, textarea, [href], [tabindex]:not([tabindex="-1"])')
      ).filter((el) => el.offsetParent !== null);
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [requestClose, showProofNotice]);

  // Focus initial dans le modal, retour à l'élément déclencheur à la fermeture
  useEffect(() => {
    const previous = document.activeElement;
    overlayRef.current?.focus?.();
    return () => {
      clearTimeout(closeTimer.current);
      clearTimeout(bubbleTimer.current);
      if (previous && typeof previous.focus === "function") previous.focus();
    };
  }, []);

  const toggleColor = (c) => {
    setSelectedColors((sel) => {
      if (!sel.includes(c)) { setPreviewColor(c); return [...sel, c]; }
      if (sel.length === 1) { setPreviewColor(c); return sel; }
      const next = sel.filter((x) => x !== c);
      setPreviewColor(next[0]); // l'aperçu ne reste jamais sur une couleur retirée
      return next;
    });
  };

  const setQ = (color, size, val) =>
    setQty((q) => ({ ...q, [color]: { ...(q[color] || {}), [size]: val } }));

  const logoFee = pack ? 0 : (front ? LOGO_FRONT_PRICE : 0) + (back ? LOGO_BACK_PRICE : 0);

  const lines = useMemo(() => {
    return selectedColors.map((color) => {
      const sizesQ = Object.fromEntries(
        Object.entries(qty[color] || {}).filter(([, v]) => parseInt(v) > 0)
      );
      const totalQty = Object.values(sizesQ).reduce((a, b) => a + parseInt(b), 0);
      const perUnit = unitPrice(product, color) + logoFee;
      return { color, sizes: sizesQ, totalQty, perUnit, lineTotal: perUnit * totalQty };
    });
  }, [selectedColors, qty, logoFee, product]);

  const totalQty = lines.reduce((a, l) => a + l.totalQty, 0);
  const total = lines.reduce((a, l) => a + l.lineTotal, 0);
  const valid = totalQty > 0;

  const doAdd = () => {
    lines.forEach((l) => {
      Object.entries(l.sizes).forEach(([size, q]) => {
        const n = parseInt(q);
        if (!n) return;
        onAdd({
          key: `${product.id}-${l.color}-${size}-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          productId: product.id,
          sku: product.sku,
          name: product.name,
          category: product.category,
          color: l.color,
          size,
          qty: n,
          placements: { front, back, position: front ? position : null, side: pack ? "inclus" : side },
          logoFrontName: front && !pack ? logoLib[faceLogo.front]?.name || null : null,
          logoBackName: back ? logoLib[faceLogo.back]?.name || null : null,
          logoScale: scales,
          unitPrice: l.perUnit,
          basePrice: unitPrice(product, l.color),
          logoFee,
          totalQty: n,
          lineTotal: l.perUnit * n,
        });
      });
    });
    // Confirmation visuelle sur le bouton, puis fermeture animée
    setAdded(true);
    closeTimer.current = setTimeout(requestClose, 750);
  };

  const add = () => {
    if (added) return;
    // Premier ajout : on explique que l'aperçu n'est pas le rendu final
    try {
      if (!pack && !localStorage.getItem("va_proof_ack")) {
        setShowProofNotice(true);
        return;
      }
    } catch {}
    doAdd();
  };

  const ackAndAdd = () => {
    try { localStorage.setItem("va_proof_ack", "1"); } catch {}
    setShowProofNotice(false);
    doAdd();
  };

  const sideOptions = [
    { id: "front", label: accessory ? "Broderie devant" : "Devant", price: LOGO_FRONT_PRICE },
    ...(canBack
      ? [
          { id: "back", label: "Dos", price: LOGO_BACK_PRICE },
          { id: "both", label: "Devant + Dos", price: LOGO_FRONT_PRICE + LOGO_BACK_PRICE },
        ]
      : []),
  ];

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence onExitComplete={onClose}>
        {open && (
          <motion.div
            key="modal"
            ref={overlayRef}
            tabIndex={-1}
            role="dialog"
            aria-modal="true"
            aria-label={product.name}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1, transition: { duration: 0.22, ease: "easeOut" } }}
            exit={{ opacity: 0, transition: { duration: 0.18, ease: "easeIn" } }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 outline-none backdrop-blur-md sm:items-center sm:p-6"
            onClick={requestClose}
          >
            <motion.div
              initial={{ y: 42, opacity: 0, scale: 0.96 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 24, opacity: 0, scale: 0.97, transition: { duration: 0.16, ease: [0.4, 0, 1, 1] } }}
              transition={{ ...SPRING_MODAL, opacity: { duration: 0.2, ease: "easeOut" } }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[94vh] w-full max-w-6xl overflow-y-auto rounded-t-[2rem] bg-white shadow-lift sm:rounded-[2rem] md:h-[min(92vh,860px)] md:overflow-hidden"
            >
              <div className="grid md:h-full md:grid-cols-[0.95fr_1.05fr]">
                {/* ------- Aperçu ------- */}
                <div className="relative flex flex-col p-5 md:h-full md:justify-center">
                  <div className="relative mx-auto w-full max-w-[min(100%,56vh)] overflow-hidden rounded-3xl bg-gradient-to-b from-[#fafbfa] to-[#f0f2f1]">
                    <AnimatePresence mode="popLayout" initial={false} custom={slide}>
                      <motion.div
                        key={`${previewColor}|${activeView}`}
                        custom={slide}
                        variants={previewVariants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{ duration: 0.28, ease: [0.32, 0.72, 0.24, 1] }}
                      >
                        <LogoOverlayImage
                          product={product}
                          logo={pack ? null : activeLogo}
                          color={previewColor}
                          view={activeView}
                          position={position}
                          scale={scales[activeView]}
                          showBack={back}
                          className="aspect-square"
                        />
                      </motion.div>
                    </AnimatePresence>
                    {!pack && (
                      <motion.span
                        key={previewColor}
                        initial={{ opacity: 0, y: -3 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.18, ease: "easeOut" }}
                        className="absolute left-4 top-4 rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-ink/70 shadow-soft backdrop-blur"
                      >
                        {previewColor}
                      </motion.span>
                    )}
                    {canBack && !pack && back && side === "both" && (
                      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 gap-1 rounded-full bg-white/95 p-1 shadow-soft backdrop-blur">
                        <SegBtn pillId="seg-apercu" active={activeView === "front"} onClick={() => setView("front")}>Devant</SegBtn>
                        <SegBtn pillId="seg-apercu" active={activeView === "back"} onClick={() => setView("back")}>Dos</SegBtn>
                      </div>
                    )}
                  </div>
                  {!pack && (
                    <p className="mx-auto mt-3 flex w-full max-w-[min(100%,56vh)] items-start gap-2 px-2 text-[11px] leading-snug text-ink/50">
                      <InfoIcon />
                      <span>
                        <span className="font-bold text-ink/70">Aperçu approximatif.</span> Ton logo sera repositionné et
                        redimensionné selon les normes d&rsquo;impression textile avant production.
                      </span>
                    </p>
                  )}
                </div>

                {/* ------- Options ------- */}
                <div className="flex flex-col p-5 md:h-full md:min-h-0 md:overflow-hidden md:p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display text-xl font-extrabold tracking-tight sm:text-2xl">{product.name}</h2>
                      <p className="mt-0.5 text-xs font-medium text-ink/40">{product.audience} · {product.desc}</p>
                    </div>
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      whileHover={{ scale: 1.08 }}
                      transition={SPRING_POP}
                      onClick={requestClose}
                      aria-label="Fermer"
                      className="rounded-full p-2 text-ink/40 transition hover:bg-paper hover:text-ink"
                    >
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
                    </motion.button>
                  </div>

                  {/* Ton logo — un seul choix + réglages toujours visibles */}
                  {!pack ? (
                    <div className="mt-3.5">
                      <SectionTitle>Ton logo</SectionTitle>
                      <div className={`grid gap-2 ${sideOptions.length === 3 ? "grid-cols-3" : "grid-cols-1"}`}>
                        {sideOptions.map((o) => (
                          <motion.button
                            key={o.id}
                            whileTap={{ scale: 0.96 }}
                            animate={{ scale: side === o.id ? 1.03 : 1 }}
                            transition={{ type: "spring", stiffness: 500, damping: 30 }}
                            onClick={() => { setSide(o.id); setView(o.id === "back" ? "back" : "front"); }}
                            className={`rounded-2xl p-3 text-center transition-colors ${
                              side === o.id
                                ? "bg-brand-600 text-white shadow-soft"
                                : "bg-paper text-ink hover:bg-brand-50"
                            }`}
                          >
                            <p className="text-sm font-bold">{o.label}</p>
                            <p className={`text-xs font-bold ${side === o.id ? "text-white/80" : "text-ink/40"}`}>+{o.price} $</p>
                          </motion.button>
                        ))}
                      </div>

                      {/* Réglages par face — les panneaux se réorganisent en douceur (layout) */}
                      <div className="relative mt-3 space-y-2.5">
                        <AnimatePresence mode="popLayout" initial={false}>
                          {side === "both" && (
                            <motion.div
                              key="seg-reglages"
                              layout="position"
                              transition={SPRING_LAYOUT}
                              variants={blockVariants}
                              initial="initial"
                              animate="animate"
                              exit="exit"
                              className="flex w-fit gap-1 rounded-full bg-white p-1 shadow-soft"
                            >
                              <SegBtn pillId="seg-reglages" active={activeView === "front"} onClick={() => setView("front")}>Devant</SegBtn>
                              <SegBtn pillId="seg-reglages" active={activeView === "back"} onClick={() => setView("back")}>Dos</SegBtn>
                            </motion.div>
                          )}

                          {activeView === "front" && front && !accessory && positions.length > 1 && (
                            <motion.div
                              key="position-devant"
                              layout="position"
                              transition={SPRING_LAYOUT}
                              variants={blockVariants}
                              initial="initial"
                              animate="animate"
                              exit="exit"
                            >
                              <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ink/45">Position (devant)</p>
                              <div className="flex flex-wrap gap-2">
                                {positions.map((p) => (
                                  <motion.button
                                    key={p.id}
                                    whileTap={{ scale: 0.94 }}
                                    onClick={() => setPosition(p.id)}
                                    className={`relative rounded-full px-4 py-2 text-xs font-bold transition-colors ${
                                      position === p.id ? "text-white" : "bg-white text-ink/60 hover:text-ink"
                                    }`}
                                  >
                                    {position === p.id && (
                                      <motion.span
                                        layoutId="position-pill"
                                        transition={SPRING_LAYOUT}
                                        className="absolute inset-0 rounded-full bg-ink shadow-soft"
                                      />
                                    )}
                                    <span className="relative z-10">{p.label}</span>
                                  </motion.button>
                                ))}
                              </div>
                            </motion.div>
                          )}
                          {activeView === "back" && (
                            <motion.p
                              key="note-dos"
                              layout="position"
                              transition={SPRING_LAYOUT}
                              variants={blockVariants}
                              initial="initial"
                              animate="animate"
                              exit="exit"
                              className="text-[11px] font-bold uppercase tracking-wide text-ink/45"
                            >
                              Dos : haut du dos, centré automatiquement
                            </motion.p>
                          )}
                        </AnimatePresence>

                        {logoLib.length > 1 && (
                          <motion.div layout="position" transition={SPRING_LAYOUT}>
                            <p className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ink/45">
                              Variation du logo ({activeView === "back" ? "dos" : "devant"})
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {logoLib.map((l, i) => (
                                <motion.button
                                  key={l.id || i}
                                  title={l.name}
                                  whileTap={{ scale: 0.94 }}
                                  whileHover={{ scale: 1.06 }}
                                  animate={{ scale: faceLogo[activeView] === i ? 1.05 : 1 }}
                                  transition={{ type: "spring", stiffness: 500, damping: 30 }}
                                  onClick={() => setFaceLogo((f) => ({ ...f, [activeView]: i }))}
                                  className="relative flex h-11 w-14 items-center justify-center rounded-xl bg-white p-1.5 shadow-soft"
                                >
                                  {faceLogo[activeView] === i && (
                                    <motion.span
                                      layoutId="logo-ring"
                                      transition={SPRING_LAYOUT}
                                      className="pointer-events-none absolute inset-0 rounded-xl ring-2 ring-brand-600"
                                    />
                                  )}
                                  <img src={l.data} alt={l.name} className="max-h-full max-w-full object-contain" />
                                </motion.button>
                              ))}
                            </div>
                          </motion.div>
                        )}

                        <motion.div layout="position" transition={SPRING_LAYOUT}>
                          <div className="flex items-center justify-between">
                            <p className="text-[11px] font-bold uppercase tracking-wide text-ink/45">
                              Taille du logo ({activeView === "back" ? "dos" : "devant"})
                            </p>
                            <span className="text-xs font-bold tabular-nums text-brand-700">{Math.round(scales[activeView] * 100)} %</span>
                          </div>
                          <div className="relative">
                            {/* Bulle de % qui suit le pouce pendant l'ajustement */}
                            <AnimatePresence>
                              {sliderActive && (
                                <motion.span
                                  key="bulle"
                                  aria-hidden="true"
                                  initial={{ opacity: 0, y: 5, scale: 0.8, x: "-50%" }}
                                  animate={{ opacity: 1, y: 0, scale: 1, x: "-50%" }}
                                  exit={{ opacity: 0, y: 4, scale: 0.9, x: "-50%", transition: { duration: 0.12 } }}
                                  transition={SPRING_POP}
                                  style={{ left: bubbleLeft }}
                                  className="pointer-events-none absolute -top-7 z-10 rounded-full bg-ink px-2 py-0.5 text-[11px] font-black tabular-nums text-white shadow-soft"
                                >
                                  {Math.round(scales[activeView] * 100)} %
                                </motion.span>
                              )}
                            </AnimatePresence>
                            <input
                              type="range" min={SCALE_MIN} max={SCALE_MAX} step="0.05"
                              value={scales[activeView]}
                              onChange={(e) => setScales((s) => ({ ...s, [activeView]: parseFloat(e.target.value) }))}
                              onPointerDown={showBubble}
                              onPointerUp={() => hideBubbleSoon(450)}
                              onPointerCancel={() => hideBubbleSoon(150)}
                              onKeyDown={(e) => { if (e.key.startsWith("Arrow")) { showBubble(); hideBubbleSoon(900); } }}
                              onBlur={() => hideBubbleSoon(0)}
                              className="mt-1.5 w-full accent-brand-600"
                              aria-label="Taille du logo"
                            />
                          </div>
                        </motion.div>
                        <motion.p layout="position" transition={SPRING_LAYOUT} className="text-[11px] text-ink/40">
                          S&rsquo;applique automatiquement à toutes les couleurs.
                        </motion.p>
                      </div>
                    </div>
                  ) : (
                    <div className="mt-3.5 rounded-2xl bg-brand-50 p-4 text-sm text-brand-800">
                      <span className="font-bold">Logo inclus dans le prix.</span> On le place sur chaque item du pack, à l&rsquo;endroit optimal.
                    </div>
                  )}

                  {/* Couleurs — TOUTES affichées */}
                  {product.colors.length > 1 && (
                    <motion.div layout="position" transition={SPRING_LAYOUT} className="mt-3.5">
                      <SectionTitle>
                        Couleurs <span className="font-medium normal-case text-ink/40">(clique pour ajouter)</span>
                      </SectionTitle>
                      <motion.div
                        className="flex flex-wrap gap-2"
                        initial="masque"
                        animate="visible"
                        variants={{
                          visible: {
                            transition: prefersReduced
                              ? undefined
                              : { staggerChildren: 0.018, delayChildren: 0.12 },
                          },
                        }}
                      >
                        {orderedColors.map((c) => {
                          const sel = selectedColors.includes(c);
                          return (
                            <motion.span
                              key={c}
                              className="inline-flex"
                              variants={{
                                masque: { opacity: 0, scale: 0.4 },
                                visible: { opacity: 1, scale: 1, transition: SPRING_POP },
                              }}
                            >
                              <motion.button
                                title={c}
                                aria-pressed={sel}
                                whileTap={{ scale: 0.9 }}
                                whileHover={{ scale: 1.12 }}
                                animate={{ scale: sel ? 1.1 : 1 }}
                                transition={{ type: "spring", stiffness: 500, damping: 28 }}
                                onClick={() => toggleColor(c)}
                                className={`relative h-8 w-8 rounded-full ${
                                  sel ? "ring-2 ring-brand-600 ring-offset-2" : ""
                                } ${isLight(c) ? "shadow-[inset_0_0_0_1px_rgba(11,15,13,0.12)]" : ""}`}
                                style={{ background: colorHex(c) }}
                              >
                                <AnimatePresence initial={false}>
                                  {sel && (
                                    <motion.span
                                      key="crochet"
                                      initial={{ scale: 0, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      exit={{ scale: 0, opacity: 0, transition: { duration: 0.1 } }}
                                      transition={SPRING_POP}
                                      className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-600 text-[9px] font-black text-white shadow"
                                    >✓</motion.span>
                                  )}
                                </AnimatePresence>
                              </motion.button>
                            </motion.span>
                          );
                        })}
                      </motion.div>
                    </motion.div>
                  )}

                  {/* Tailles par couleur — seule zone qui défile sur desktop */}
                  <motion.div layout="position" transition={SPRING_LAYOUT} className="mt-3.5 flex min-h-0 flex-col md:flex-1">
                    <SectionTitle>{sizes.length > 1 ? "Tailles et quantités" : "Quantité"}</SectionTitle>
                    <div className="relative space-y-2.5 pr-1 md:min-h-0 md:flex-1 md:overflow-y-auto">
                      <AnimatePresence mode="popLayout" initial={false}>
                        {selectedColors.map((color) => {
                          const line = lines.find((l) => l.color === color);
                          return (
                            <motion.div
                              key={color}
                              layout="position"
                              initial={{ opacity: 0, y: 12, scale: 0.98 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.97, transition: { duration: 0.15, ease: "easeIn" } }}
                              transition={SPRING_LAYOUT}
                              onClick={() => setPreviewColor(color)}
                              className={`cursor-pointer rounded-2xl p-3.5 transition ${previewColor === color ? "bg-brand-50" : "bg-paper hover:bg-brand-50/50"}`}
                            >
                              <div className="mb-2 flex items-center justify-between">
                                <span className="flex items-center gap-2 text-sm font-bold">
                                  <span className={`h-4 w-4 rounded-full ${isLight(color) ? "shadow-[inset_0_0_0_1px_rgba(11,15,13,0.12)]" : ""}`} style={{ background: colorHex(color) }} />
                                  {color}
                                </span>
                                <AnimatePresence initial={false}>
                                  {line?.totalQty > 0 && (
                                    <motion.span
                                      key="badge"
                                      initial={{ scale: 0.4, opacity: 0 }}
                                      animate={{ scale: 1, opacity: 1 }}
                                      exit={{ scale: 0.4, opacity: 0, transition: { duration: 0.12 } }}
                                      transition={SPRING_POP}
                                      className="rounded-full bg-brand-600 px-2 py-0.5 text-[11px] font-black text-white"
                                    >
                                      <motion.span
                                        key={line.totalQty}
                                        initial={{ opacity: 0, y: 5 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        transition={{ duration: 0.15, ease: "easeOut" }}
                                        className="block tabular-nums"
                                      >
                                        {line.totalQty}
                                      </motion.span>
                                    </motion.span>
                                  )}
                                </AnimatePresence>
                              </div>
                              <div className={`grid gap-1.5 ${sizes.length > 1 ? "grid-cols-7" : "grid-cols-4"}`}>
                                {sizes.map((s) => (
                                  <div key={s} className="text-center">
                                    <p className="mb-1 text-[10px] font-bold text-ink/45">{s}</p>
                                    <input
                                      type="number" min="0" placeholder="·" inputMode="numeric"
                                      value={qty[color]?.[s] ?? ""}
                                      onClick={(e) => e.stopPropagation()}
                                      onChange={(e) => setQ(color, s, e.target.value)}
                                      {...selectAllProps}
                                      className="w-full rounded-lg bg-white px-0.5 py-1.5 text-center text-sm font-bold shadow-soft outline-none transition focus:ring-2 focus:ring-brand-500"
                                    />
                                  </div>
                                ))}
                              </div>
                            </motion.div>
                          );
                        })}
                      </AnimatePresence>
                    </div>
                  </motion.div>

                  {/* Total */}
                  <div className="sticky bottom-0 -mx-5 mt-3 bg-white/95 px-5 py-3 backdrop-blur md:-mx-6 md:mt-auto md:px-6">
                    <div className="flex items-center justify-between gap-4">
                      <div>
                        <AnimatePresence initial={false}>
                          {!pack && totalQty > 0 && (
                            <motion.p
                              key="meta"
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              exit={{ opacity: 0, transition: { duration: 0.12 } }}
                              transition={{ duration: 0.2 }}
                              className="text-[11px] text-ink/45"
                            >
                              {totalQty} unité(s) · logo {fmt(logoFee)}/unité inclus
                            </motion.p>
                          )}
                        </AnimatePresence>
                        {/* Le montant glisse verticalement quand il change */}
                        <div className="relative overflow-hidden">
                          <AnimatePresence mode="popLayout" initial={false}>
                            <motion.p
                              key={totalQty > 0 ? fmt(total) : "vide"}
                              initial={{ opacity: 0, y: 15 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -15 }}
                              transition={{ duration: 0.18, ease: [0.3, 0.8, 0.4, 1] }}
                              className="font-display text-2xl font-extrabold tabular-nums"
                            >
                              {totalQty > 0 ? fmt(total) : "Choisis tes quantités"}
                            </motion.p>
                          </AnimatePresence>
                        </div>
                      </div>
                      <motion.button
                        onClick={add}
                        disabled={!valid || added}
                        whileHover={valid && !added ? { scale: 1.02 } : undefined}
                        whileTap={valid && !added ? { scale: 0.97 } : undefined}
                        animate={added ? { scale: [1, 1.04, 1] } : { scale: 1 }}
                        transition={added ? { duration: 0.35, times: [0, 0.4, 1], ease: "easeOut" } : SPRING_POP}
                        className={`min-w-[190px] rounded-full px-8 py-3.5 text-sm font-bold text-white shadow-soft transition-[background-color,opacity] duration-200 ${
                          added
                            ? "bg-ink"
                            : "bg-brand-600 enabled:hover:bg-brand-500 disabled:cursor-not-allowed disabled:opacity-40"
                        }`}
                      >
                        <AnimatePresence mode="wait" initial={false}>
                          {added ? (
                            <motion.span
                              key="ok"
                              initial={{ opacity: 0, y: 10, scale: 0.9 }}
                              animate={{ opacity: 1, y: 0, scale: 1 }}
                              exit={{ opacity: 0, y: -8 }}
                              transition={{ ...SPRING_POP, opacity: { duration: 0.12 } }}
                              className="flex items-center justify-center gap-2"
                            >
                              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                                <motion.path
                                  d="M20 6 9 17l-5-5"
                                  initial={{ pathLength: 0 }}
                                  animate={{ pathLength: 1 }}
                                  transition={{ duration: 0.3, ease: "easeOut", delay: 0.05 }}
                                />
                              </svg>
                              Ajouté!
                            </motion.span>
                          ) : (
                            <motion.span
                              key="add"
                              initial={{ opacity: 0, y: 8 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, y: -8 }}
                              transition={{ duration: 0.15 }}
                              className="block"
                            >
                              Ajouter au panier
                            </motion.span>
                          )}
                        </AnimatePresence>
                      </motion.button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Pop-up une seule fois : l'aperçu n'est pas le rendu final */}
            <AnimatePresence>
              {showProofNotice && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, transition: { duration: 0.15 } }}
                  transition={{ duration: 0.2 }}
                  className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/50 p-6 backdrop-blur-sm"
                  onClick={(e) => e.stopPropagation()}
                >
                  <motion.div
                    initial={{ scale: 0.92, y: 24, opacity: 0 }}
                    animate={{ scale: 1, y: 0, opacity: 1 }}
                    exit={{ scale: 0.95, y: 10, opacity: 0, transition: { duration: 0.15, ease: [0.4, 0, 1, 1] } }}
                    transition={{ ...SPRING_MODAL, opacity: { duration: 0.18, ease: "easeOut" } }}
                    className="w-full max-w-sm rounded-3xl bg-white p-7 text-center shadow-lift"
                  >
                    <motion.div
                      initial={{ scale: 0.6, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ ...SPRING_POP, delay: 0.1 }}
                      className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-50 text-brand-700"
                    >
                      <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                    </motion.div>
                    <h3 className="mt-4 font-display text-xl font-extrabold">Ton aperçu, perfectionné par des pros</h3>
                    <p className="mt-2 text-sm leading-relaxed text-ink/60">
                      Ce que tu vois est un <span className="font-bold text-ink">aperçu approximatif</span>. Avant la
                      production, notre équipe retravaille ton logo (position, taille, qualité) selon les
                      <span className="font-bold text-ink"> normes d&rsquo;impression textile</span>, pour un résultat
                      parfait sur chaque morceau.
                    </p>
                    <motion.button
                      autoFocus
                      whileTap={{ scale: 0.97 }}
                      onClick={ackAndAdd}
                      className="mt-5 w-full rounded-full bg-brand-600 py-3.5 text-sm font-bold text-white shadow-soft transition hover:bg-brand-500"
                    >
                      Parfait, compris
                    </motion.button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  );
}

function SectionTitle({ children }) {
  return <p className="mb-2 text-xs font-bold uppercase tracking-widest text-ink/50">{children}</p>;
}

// Segment Devant/Dos : la pastille foncée glisse d'un choix à l'autre (layoutId).
// pillId isole chaque groupe pour que la pastille ne saute pas entre les contrôles.
function SegBtn({ active, onClick, children, pillId }) {
  return (
    <motion.button
      whileTap={{ scale: 0.94 }}
      onClick={onClick}
      className={`relative rounded-full px-3.5 py-1.5 text-xs font-bold transition-colors ${
        active ? "text-white" : "text-ink/55 hover:text-ink"
      }`}
    >
      {active && (
        <motion.span
          layoutId={pillId ? `${pillId}-pill` : undefined}
          transition={SPRING_LAYOUT}
          className="absolute inset-0 rounded-full bg-ink"
        />
      )}
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
}

function InfoIcon() {
  return (
    <svg className="mt-0.5 shrink-0 text-brand-600" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
  );
}
