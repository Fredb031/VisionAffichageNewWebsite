

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, MotionConfig, useReducedMotion } from "framer-motion";
import { FLOATERS } from "~/data/generatedImages";

const MOLE_IMG = FLOATERS[0]?.src;
const GOAL = 5;
const DURATION = 12; // secondes
const POP_MS = 680;
const HIT_MS = 240; // fenêtre du feedback d'impact (squash, flash du trou, +1)
const EASE = [0.22, 1, 0.36, 1];

/**
 * Jeu de la taupe : attrape 5 hoodies en 12 secondes → 10 % de rabais.
 * Apparaît une seule fois à l'arrivée sur la page produits.
 * Se met en pause tout seul si l'onglet perd le focus, et ne laisse
 * aucun timer actif au démontage.
 */
export default function MoleGame({ onWin }) {
  const reduced = useReducedMotion();
  const [phase, setPhase] = useState(null); // null | intro | playing | won | lost
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(DURATION);
  const [hole, setHole] = useState(-1);
  const [hit, setHit] = useState(-1);
  const [popFx, setPopFx] = useState(null); // petit « +1 » qui monte au-dessus du trou touché
  const timers = useRef([]);
  const hitTimer = useRef(null);

  useEffect(() => {
    try {
      if (localStorage.getItem("va_mole_done") || localStorage.getItem("va_discount")) return;
    } catch {}
    const t = setTimeout(() => setPhase("intro"), 900);
    return () => clearTimeout(t);
  }, []);

  const clearAll = useCallback(() => {
    timers.current.forEach(clearInterval);
    timers.current = [];
  }, []);

  /* Aucun timer orphelin si le composant est démonté en pleine partie */
  useEffect(() => {
    return () => {
      clearAll();
      clearTimeout(hitTimer.current);
    };
  }, [clearAll]);

  const runTimers = useCallback(() => {
    const moveMole = () =>
      setHole((h) => {
        let n;
        do { n = Math.floor(Math.random() * 9); } while (n === h);
        return n;
      });
    moveMole();
    timers.current.push(setInterval(moveMole, POP_MS));
    timers.current.push(setInterval(() => {
      setTimeLeft((t) => (t <= 0.1 ? 0 : +(t - 0.1).toFixed(1)));
    }, 100));
  }, []);

  const start = useCallback(() => {
    clearAll();
    setScore(0);
    setTimeLeft(DURATION);
    setHit(-1);
    setPopFx(null);
    setPhase("playing");
    runTimers();
  }, [clearAll, runTimers]);

  /* Pause propre quand l'onglet perd le focus, reprise au retour */
  useEffect(() => {
    if (phase !== "playing") return;
    const onVis = () => {
      clearAll();
      if (document.hidden) {
        setHole(-1);
      } else {
        runTimers();
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [phase, clearAll, runTimers]);

  // Fin de partie
  useEffect(() => {
    if (phase !== "playing") return;
    if (score >= GOAL) {
      clearAll();
      try {
        localStorage.setItem("va_discount", "10");
        localStorage.setItem("va_mole_done", "1");
      } catch {}
      onWin?.(10);
      setPhase("won");
    } else if (timeLeft <= 0) {
      clearAll();
      setPhase("lost");
    }
  }, [score, timeLeft, phase, onWin, clearAll]);

  const whack = (i) => {
    if (phase !== "playing" || i !== hole) return;
    setHit(i);
    setScore((s) => s + 1);
    setPopFx({ id: Date.now(), hole: i });
    setHole(-1);
    clearTimeout(hitTimer.current);
    hitTimer.current = setTimeout(() => setHit(-1), HIT_MS);
  };

  const close = useCallback(() => {
    clearAll();
    try { localStorage.setItem("va_mole_done", "1"); } catch {}
    setPhase(null);
  }, [clearAll]);

  /* Échap ferme le jeu (accessibilité clavier) */
  useEffect(() => {
    if (!phase) return;
    const onKey = (e) => { if (e.key === "Escape") close(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, close]);

  if (!MOLE_IMG) return null;

  return (
    <MotionConfig reducedMotion="user">
      <AnimatePresence>
        {phase && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/55 p-5 backdrop-blur-sm"
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="Mini-jeu pour débloquer un rabais"
              initial={{ scale: 0.9, y: 24 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 12, opacity: 0 }}
              transition={{ type: "spring", damping: 24, stiffness: 300 }}
              className="w-full max-w-md overflow-hidden rounded-[2rem] bg-white text-center shadow-lift"
            >
              {/* La carte morphe en douceur entre les phases : contenu en
                  mode="wait" + hauteur mesurée animée, aucun saut. */}
              <MorphPanel reduced={reduced} className="overflow-hidden">
                <AnimatePresence mode="wait" initial={false}>
                  {phase === "intro" && (
                    <motion.div
                      key="intro"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10, transition: { duration: 0.18, ease: EASE } }}
                      transition={{ duration: 0.35, ease: EASE }}
                      className="p-8"
                    >
                      <motion.img
                        src={MOLE_IMG}
                        alt="Hoodie"
                        className="mx-auto h-24 w-24 object-contain"
                        animate={{ y: [0, -10, 0], rotate: [-4, 4, -4] }}
                        transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
                      />
                      <h3 className="mt-3 font-display text-2xl font-extrabold">Attrape les hoodies!</h3>
                      <p className="mt-2 text-sm text-ink/60">
                        Attrapes-en <span className="font-black text-ink">{GOAL}</span> en{" "}
                        <span className="font-black text-ink">{DURATION} secondes</span> et gagne{" "}
                        <span className="font-black text-brand-700">10 % de rabais</span> sur ta commande.
                      </p>
                      <div className="mt-6 flex items-center justify-center gap-3">
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.96 }}
                          onClick={close}
                          className="rounded-full px-5 py-3 text-sm font-semibold text-ink/50 transition-colors hover:bg-paper"
                        >
                          Non merci
                        </motion.button>
                        <motion.button
                          type="button"
                          autoFocus
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.96 }}
                          transition={{ type: "spring", stiffness: 400, damping: 22 }}
                          onClick={start}
                          className="rounded-full bg-brand-600 px-9 py-3.5 text-sm font-bold text-white shadow-soft transition-colors hover:bg-brand-500"
                        >
                          Jouer!
                        </motion.button>
                      </div>
                    </motion.div>
                  )}

                  {phase === "playing" && (
                    <motion.div
                      key="playing"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10, transition: { duration: 0.18, ease: EASE } }}
                      transition={{ duration: 0.35, ease: EASE }}
                      className="p-4 sm:p-6"
                    >
                      <div className="mb-4 flex items-center justify-between px-1">
                        <span className="font-display text-lg font-extrabold">
                          {/* Le score pop : remonté en vert, il retombe en noir */}
                          <motion.span
                            key={score}
                            initial={score === 0 ? false : { scale: 1.5, color: "#12b76a" }}
                            animate={{ scale: 1, color: "#0b0f0d" }}
                            transition={{ type: "spring", stiffness: 550, damping: 17, color: { duration: 0.45, ease: "easeOut" } }}
                            className="inline-block"
                          >
                            {score}
                          </motion.span>
                          <span className="text-ink/35">/{GOAL}</span>
                        </span>
                        <div
                          role="progressbar"
                          aria-label="Temps restant"
                          aria-valuemin={0}
                          aria-valuemax={DURATION}
                          aria-valuenow={Math.ceil(timeLeft)}
                          className="h-2 w-32 overflow-hidden rounded-full bg-paper"
                        >
                          <div
                            className={`h-full rounded-full bg-gradient-to-r transition-[width] duration-150 ease-linear ${
                              timeLeft <= 3 ? "from-red-500 to-red-600" : "from-brand-500 to-brand-600"
                            }`}
                            style={{ width: `${(timeLeft / DURATION) * 100}%` }}
                          />
                        </div>
                        <span
                          className={`w-12 text-right font-display text-lg font-extrabold tabular-nums ${
                            timeLeft <= 3 ? "text-red-600" : ""
                          }`}
                        >
                          {Math.ceil(timeLeft)}s
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
                        {Array.from({ length: 9 }).map((_, i) => (
                          <motion.button
                            key={i}
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            transition={{ type: "spring", stiffness: 480, damping: 28 }}
                            onPointerDown={() => whack(i)}
                            onClick={() => whack(i)}
                            aria-label={`Trou ${i + 1}`}
                            className="relative aspect-square cursor-pointer touch-manipulation select-none overflow-hidden rounded-2xl bg-paper shadow-[inset_0_3px_8px_rgba(11,15,13,0.08)]"
                          >
                            <AnimatePresence>
                              {(hole === i || hit === i) && (
                                <motion.img
                                  key={`m${i}`}
                                  src={MOLE_IMG}
                                  alt=""
                                  style={{ originY: 1 }}
                                  initial={{ y: "72%", scaleY: 0.8, scaleX: 1.1, opacity: 0 }}
                                  animate={
                                    hit === i
                                      ? {
                                          /* Impact : écrasé vers le sol, puis disparaît */
                                          y: "16%",
                                          scaleY: 0.45,
                                          scaleX: 1.3,
                                          opacity: 0,
                                          transition: { duration: 0.18, ease: "easeOut" },
                                        }
                                      : {
                                          /* Surgissement avec squash & stretch, ancré au sol */
                                          y: "6%",
                                          opacity: 1,
                                          scaleY: [0.8, 1.05, 1],
                                          scaleX: [1.1, 0.95, 1],
                                          transition: {
                                            y: { type: "spring", stiffness: 500, damping: 24 },
                                            opacity: { duration: 0.12 },
                                            scaleY: { duration: 0.34, times: [0, 0.62, 1], ease: "easeOut" },
                                            scaleX: { duration: 0.34, times: [0, 0.62, 1], ease: "easeOut" },
                                          },
                                        }
                                  }
                                  exit={{ y: "72%", scaleY: 0.85, scaleX: 1.05, opacity: 0, transition: { duration: 0.16, ease: "easeIn" } }}
                                  className="pointer-events-none absolute inset-2 m-auto object-contain"
                                  draggable={false}
                                />
                              )}
                            </AnimatePresence>
                            {/* Flash bref du trou au hit */}
                            {hit === i && !reduced && (
                              <motion.div
                                aria-hidden="true"
                                initial={{ opacity: 0.7 }}
                                animate={{ opacity: 0 }}
                                transition={{ duration: 0.22, ease: "easeOut" }}
                                className="pointer-events-none absolute inset-0 rounded-2xl bg-brand-300"
                              />
                            )}
                            {/* Petit « +1 » qui monte et s'efface */}
                            {popFx && popFx.hole === i && (
                              <motion.span
                                key={popFx.id}
                                aria-hidden="true"
                                initial={{ opacity: 0, y: 6, scale: 0.5 }}
                                animate={{ opacity: [0, 1, 1, 0], y: -26, scale: [0.5, 1.15, 1, 0.95] }}
                                transition={{ duration: 0.55, times: [0, 0.2, 0.7, 1], ease: "easeOut" }}
                                className="pointer-events-none absolute inset-x-0 top-1 z-10 font-display text-xl font-extrabold text-brand-600 drop-shadow-sm"
                              >
                                +1
                              </motion.span>
                            )}
                          </motion.button>
                        ))}
                      </div>
                    </motion.div>
                  )}

                  {phase === "won" && (
                    <motion.div
                      key="won"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10, transition: { duration: 0.18, ease: EASE } }}
                      transition={{ duration: 0.35, ease: EASE }}
                      className="relative p-8"
                    >
                      <Confetti />
                      <p className="text-4xl" aria-hidden="true">🎉</p>
                      {/* Le 10 % tombe du haut avec un spring lourd et atterrit de travers */}
                      <motion.div
                        aria-hidden="true"
                        initial={{ y: -110, opacity: 0, rotate: -12, scale: 1.1 }}
                        animate={{ y: 0, opacity: 1, rotate: -3, scale: 1 }}
                        transition={{
                          type: "spring",
                          stiffness: 250,
                          damping: 16,
                          mass: 1.4,
                          delay: 0.15,
                          opacity: { duration: 0.2, delay: 0.15 },
                        }}
                        className="mx-auto mt-2 inline-block rounded-2xl bg-brand-600 px-7 py-2.5 font-display text-4xl font-black tracking-tight text-white shadow-lift"
                      >
                        10 %
                      </motion.div>
                      <motion.h3
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0, transition: { delay: 0.42, duration: 0.35, ease: EASE } }}
                        className="mt-4 font-display text-2xl font-extrabold"
                      >
                        10 % de rabais débloqué!
                      </motion.h3>
                      <motion.p
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0, transition: { delay: 0.52, duration: 0.35, ease: EASE } }}
                        className="mt-2 text-sm text-ink/60"
                      >
                        Bien joué. Ton rabais est <span className="font-bold text-brand-700">appliqué automatiquement</span> à ta commande.
                      </motion.p>
                      <motion.button
                        type="button"
                        autoFocus
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0, transition: { delay: 0.62, duration: 0.35, ease: EASE } }}
                        whileTap={{ scale: 0.98 }}
                        transition={{ type: "spring", stiffness: 500, damping: 30 }}
                        onClick={() => setPhase(null)}
                        className="mt-6 w-full rounded-full bg-brand-600 py-3.5 text-sm font-bold text-white shadow-soft transition-colors hover:bg-brand-500"
                      >
                        Magasiner avec mon rabais
                      </motion.button>
                    </motion.div>
                  )}

                  {phase === "lost" && (
                    <motion.div
                      key="lost"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10, transition: { duration: 0.18, ease: EASE } }}
                      transition={{ duration: 0.35, ease: EASE }}
                      className="p-8"
                    >
                      <p className="text-4xl" aria-hidden="true">😅</p>
                      <h3 className="mt-2 font-display text-2xl font-extrabold">Proche! {score}/{GOAL}</h3>
                      <p className="mt-2 text-sm text-ink/60">Ils sont rapides ces hoodies. Une dernière chance?</p>
                      <div className="mt-6 flex items-center justify-center gap-3">
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.96 }}
                          onClick={close}
                          className="rounded-full px-5 py-3 text-sm font-semibold text-ink/50 transition-colors hover:bg-paper"
                        >
                          Fermer
                        </motion.button>
                        <motion.button
                          type="button"
                          autoFocus
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.96 }}
                          transition={{ type: "spring", stiffness: 400, damping: 22 }}
                          onClick={start}
                          className="rounded-full bg-brand-600 px-9 py-3.5 text-sm font-bold text-white shadow-soft transition-colors hover:bg-brand-500"
                        >
                          Réessayer
                        </motion.button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </MorphPanel>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </MotionConfig>
  );
}

function Confetti() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {Array.from({ length: 18 }).map((_, i) => (
        <motion.span
          key={i}
          initial={{ y: -20, x: `${(i * 37) % 100}%`, opacity: 1, rotate: 0 }}
          animate={{ y: 340, opacity: 0, rotate: 260 }}
          transition={{ duration: 1.6 + (i % 5) * 0.25, delay: (i % 6) * 0.12, ease: "easeIn" }}
          className="absolute h-2 w-2 rounded-sm"
          style={{ background: ["#12b76a", "#0b0f0d", "#38cd87", "#e8b23a", "#c8262e"][i % 5] }}
        />
      ))}
    </div>
  );
}

/* Panneau à hauteur mesurée : ResizeObserver + spring sur la hauteur, pour que
   la carte morphe sans saut quand le contenu change (mode="wait" au-dessus).
   L'observer est déconnecté au démontage, aucune fuite. */
function MorphPanel({ reduced, className, style, animate, transition, children, ...rest }) {
  const innerRef = useRef(null);
  const [h, setH] = useState(null);

  useEffect(() => {
    const el = innerRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      const next = el.offsetHeight;
      setH((prev) => (prev === next ? prev : next));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const target = { ...(animate || {}) };
  if (h != null) target.height = h;

  return (
    <motion.div
      {...rest}
      animate={target}
      transition={{
        ...(transition || {}),
        height: reduced ? { duration: 0 } : { type: "spring", stiffness: 280, damping: 32, mass: 0.9 },
      }}
      className={className}
      style={style}
    >
      <div ref={innerRef}>{children}</div>
    </motion.div>
  );
}
