

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { fmt, getProduct, productImage, FREE_SHIPPING_THRESHOLD } from "~/lib/catalog";

const POS_LABEL = {
  "coeur-gauche": "cœur gauche",
  "coeur-droit": "cœur droit",
  "centre": "centré",
  "inclus": "logo inclus",
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// Cibles d'animation à référence stable : évite que les pulses (keyframes)
// se relancent à chaque rendu du composant
const BAR_PULSE = { scale: [1, 1.04, 1] };
const BAR_REST = { scale: 1 };
const UNLOCK_IN = { opacity: 0, scale: 0.92 };
const UNLOCK_ANIM = { opacity: 1, scale: [0.92, 1.06, 1] };

// Montant animé : l'ancien chiffre glisse vers le haut, le nouveau arrive du bas
function Amount({ value, className = "" }) {
  return (
    <span className={`relative inline-flex overflow-hidden ${className}`}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={value}
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -12, opacity: 0 }}
          transition={{ duration: 0.22, ease: "easeOut" }}
        >
          {fmt(value)}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

// Spinner inline de l'état d'envoi : rotation en boucle (transform seulement)
function Spinner({ reduceMotion }) {
  return (
    <motion.svg
      aria-hidden="true"
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      initial={{ opacity: 0, scale: 0.5 }}
      animate={reduceMotion ? { opacity: 1, scale: 1 } : { opacity: 1, scale: 1, rotate: 360 }}
      transition={
        reduceMotion
          ? { duration: 0.15 }
          : {
              opacity: { duration: 0.15 },
              scale: { duration: 0.15 },
              rotate: { repeat: Infinity, duration: 0.8, ease: "linear" },
            }
      }
      className="shrink-0"
    >
      <path d="M21 12a9 9 0 1 1-6.2-8.56" />
    </motion.svg>
  );
}

export default function CartDrawer({ open, items, logo, logoName, discountPct = 0, onClose, onRemove }) {
  const reduceMotion = useReducedMotion();
  const [step, setStep] = useState("cart"); // cart | form | sending
  const [error, setError] = useState("");
  const [policyOk, setPolicyOk] = useState(false);
  const [touched, setTouched] = useState({});
  const [form, setForm] = useState({
    company: "", contact: "", email: "", phone: "",
    address: "", city: "", postal: "", notes: "",
  });

  // Direction du glissement entre les étapes (1 : panier vers formulaire, -1 : retour)
  const stepDir = useRef(1);

  // Cascade des items : seulement au moment de l'ouverture du panier.
  // Le drapeau se réarme à chaque ouverture, puis s'éteint pour que les items
  // ajoutés ou réaffichés ensuite entrent sans délai.
  const cascadeRef = useRef(true);
  const prevOpenRef = useRef(false);
  if (open && !prevOpenRef.current) cascadeRef.current = true;
  prevOpenRef.current = open;
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => { cascadeRef.current = false; }, 700);
    return () => clearTimeout(t);
  }, [open]);

  // Escape ferme le panier (sauf pendant l'envoi)
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape" && step !== "sending") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, step, onClose]);

  // Préremplissage depuis le compte client
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (cancelled) return;
        const c = d.customer;
        if (!c) return;
        setForm((f) => ({
          ...f,
          company: f.company || c.company || "",
          contact: f.contact || c.contact || "",
          email: f.email || c.email || "",
          phone: f.phone || c.phone || "",
          address: f.address || c.address || "",
          city: f.city || c.city || "",
          postal: f.postal || c.postal || "",
        }));
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [open]);

  const subtotal = items.reduce((a, i) => a + i.lineTotal, 0);
  const rebate = subtotal * (discountPct / 100);
  const total = subtotal - rebate;
  const shippingLeft = Math.max(0, FREE_SHIPPING_THRESHOLD - total);
  const shippingPct = Math.min(100, (total / FREE_SHIPPING_THRESHOLD) * 100);
  const freeShipUnlocked = items.length > 0 && shippingLeft <= 0;

  const set = (k) => (e) => {
    const v = e.target.value;
    setForm((f) => ({ ...f, [k]: v }));
  };
  const markTouched = (k) => () => setTouched((t) => (t[k] ? t : { ...t, [k]: true }));

  // Validation légère : courriel bien formé, téléphone à 10 chiffres (11 avec le 1)
  const emailOk = EMAIL_RE.test(form.email.trim());
  const phoneDigits = form.phone.replace(/\D/g, "");
  const phoneOk = phoneDigits.length === 10 || (phoneDigits.length === 11 && phoneDigits.startsWith("1"));
  const fieldsFilled = !!(form.company && form.contact && form.email && form.phone && form.address && form.city);
  const formValid = fieldsFilled && emailOk && phoneOk && policyOk;

  const emailError =
    touched.email && form.email && !emailOk
      ? "Courriel invalide. Vérifie le format (ex. nom@entreprise.com)."
      : "";
  const phoneError =
    touched.phone && form.phone && !phoneOk
      ? "Numéro incomplet. Il faut 10 chiffres (ex. 418 555 1234)."
      : "";

  // Raison précise pour laquelle le bouton reste désactivé
  const blocker = formValid
    ? null
    : !fieldsFilled
    ? { msg: "Remplis les champs marqués d'un astérisque (*) pour continuer.", warn: false }
    : !emailOk
    ? { msg: "Vérifie ton courriel avant d'envoyer.", warn: false }
    : !phoneOk
    ? { msg: "Vérifie ton numéro de téléphone (10 chiffres).", warn: false }
    : { msg: "Coche la case des politiques ci-dessus pour confirmer ta commande.", warn: true };

  const goToForm = () => { stepDir.current = 1; setStep("form"); };
  const backToCart = () => { stepDir.current = -1; setStep("cart"); };

  const submit = async () => {
    if (!formValid || step === "sending") return;
    setError("");
    setStep("sending");
    // Bibliothèque des variations de logo utilisées dans la commande
    let logos = {};
    try {
      const lib = JSON.parse(localStorage.getItem("va_logos") || "[]");
      const used = new Set();
      items.forEach((i) => {
        if (i.logoFrontName) used.add(i.logoFrontName);
        if (i.logoBackName) used.add(i.logoBackName);
      });
      lib.forEach((l) => { if (used.has(l.name)) logos[l.name] = l.data; });
    } catch {}
    try {
      const res = await fetch("/commander", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customer: form, items, total, discountPct, logo, logoName, logos }),
      });
      let data = {};
      try { data = await res.json(); } catch {}
      if (!res.ok) throw new Error(data.error || "Le serveur a refusé la commande. Réessaie dans un instant.");
      if (data.checkoutUrl) window.location.href = data.checkoutUrl;
      else window.location.href = `/merci?order=${data.orderNumber}`;
    } catch (e) {
      setError(
        e instanceof TypeError
          ? "Impossible de joindre le serveur. Vérifie ta connexion internet, puis réessaie."
          : e.message || "Une erreur est survenue. Réessaie dans un instant."
      );
      setStep("form");
    }
  };

  // Glissement horizontal entre le panier et le formulaire
  const stepVariants = {
    enter: (dir) => (reduceMotion ? { opacity: 0 } : { x: dir > 0 ? 56 : -56, opacity: 0 }),
    center: {
      x: 0,
      opacity: 1,
      transition: reduceMotion
        ? { duration: 0.18 }
        : { type: "spring", stiffness: 430, damping: 38, mass: 0.9 },
    },
    exit: (dir) =>
      reduceMotion
        ? { opacity: 0, transition: { duration: 0.12 } }
        : { x: dir > 0 ? -56 : 56, opacity: 0, transition: { duration: 0.2, ease: "easeIn" } },
  };

  const cascade = cascadeRef.current && !reduceMotion;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.22, ease: "easeIn" } }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="fixed inset-0 z-40 bg-ink/45 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.aside
            role="dialog"
            aria-modal="true"
            aria-label="Panier"
            initial={reduceMotion ? { opacity: 0 } : { x: "100%" }}
            animate={reduceMotion ? { opacity: 1 } : { x: 0 }}
            exit={
              reduceMotion
                ? { opacity: 0, transition: { duration: 0.18 } }
                : { x: "100%", transition: { duration: 0.28, ease: [0.32, 0, 0.67, 0] } }
            }
            transition={
              reduceMotion
                ? { duration: 0.2 }
                : { type: "spring", stiffness: 420, damping: 33, mass: 1 }
            }
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col bg-white shadow-lift"
          >
            <div className="flex items-center justify-between p-5 shadow-[0_1px_12px_rgba(11,15,13,0.04)]">
              <h3 className="font-display text-xl font-extrabold">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.span
                    key={step === "cart" ? "titre-panier" : "titre-infos"}
                    initial={{ opacity: 0, y: reduceMotion ? 0 : 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: reduceMotion ? 0 : -6 }}
                    transition={{ duration: 0.15, ease: "easeOut" }}
                    className="block"
                  >
                    {step === "cart" ? "Ta commande" : "Tes informations"}
                  </motion.span>
                </AnimatePresence>
              </h3>
              <button
                onClick={onClose}
                aria-label="Fermer le panier"
                className="rounded-full p-2 text-ink/40 transition hover:bg-paper hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
              </button>
            </div>

            {/* Barre livraison gratuite : remplissage avec ressort + pulse discret au seuil */}
            <AnimatePresence initial={false}>
              {step === "cart" && items.length > 0 && (
                <motion.div
                  key="barre-livraison"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.24, ease: "easeOut" }}
                  className="overflow-hidden"
                >
                  <div className="px-5 py-3">
                    <AnimatePresence mode="wait" initial={false}>
                      {shippingLeft > 0 ? (
                        <motion.p
                          key="livraison-restante"
                          initial={{ opacity: 0, y: reduceMotion ? 0 : 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: reduceMotion ? 0 : -4 }}
                          transition={{ duration: 0.16 }}
                          className="text-xs font-semibold text-ink/55"
                        >
                          Plus que <span className="font-bold text-brand-700">{fmt(shippingLeft)}</span> pour la livraison gratuite
                        </motion.p>
                      ) : (
                        <motion.p
                          key="livraison-gratuite"
                          initial={reduceMotion ? { opacity: 0 } : UNLOCK_IN}
                          animate={reduceMotion ? { opacity: 1 } : UNLOCK_ANIM}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.4, ease: "easeOut" }}
                          className="origin-left text-xs font-bold text-brand-700"
                        >
                          ✓ Livraison gratuite débloquée
                        </motion.p>
                      )}
                    </AnimatePresence>
                    <motion.div
                      className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-paper"
                      animate={freeShipUnlocked && !reduceMotion ? BAR_PULSE : BAR_REST}
                      transition={{ duration: 0.45, ease: "easeOut" }}
                    >
                      <motion.div
                        className="h-full w-full rounded-full bg-gradient-to-r from-brand-500 to-brand-600"
                        style={{ originX: 0 }}
                        initial={{ scaleX: 0 }}
                        animate={{ scaleX: shippingPct / 100 }}
                        transition={
                          reduceMotion
                            ? { duration: 0 }
                            : { type: "spring", stiffness: 130, damping: 19, mass: 0.9 }
                        }
                      />
                    </motion.div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="relative flex-1 overflow-y-auto overflow-x-hidden p-5">
              <AnimatePresence mode="popLayout" initial={false} custom={stepDir.current}>
                {step === "cart" ? (
                  <motion.div
                    key="etape-panier"
                    custom={stepDir.current}
                    variants={stepVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    className="w-full"
                  >
                    {items.length === 0 ? (
                      <div className="mt-16 text-center">
                        <p className="text-4xl">🛒</p>
                        <p className="mt-3 text-sm text-ink/45">Ton panier est vide.</p>
                      </div>
                    ) : (
                      <div className="relative space-y-3">
                        <AnimatePresence mode="popLayout">
                          {items.map((i, idx) => {
                            const product = getProduct(i.productId);
                            const thumb = product ? productImage(product, i.color, "front") : i.image;
                            return (
                              <motion.div
                                key={i.key}
                                layout
                                initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 14 }}
                                animate={{ opacity: 1, y: 0 }}
                                exit={
                                  reduceMotion
                                    ? { opacity: 0, transition: { duration: 0.12 } }
                                    : { opacity: 0, x: 32, transition: { duration: 0.18 } }
                                }
                                transition={{
                                  type: "spring",
                                  stiffness: 460,
                                  damping: 34,
                                  delay: cascade ? Math.min(0.1 + idx * 0.05, 0.4) : 0,
                                }}
                                className="flex gap-3 rounded-2xl bg-paper/70 p-3"
                              >
                                <img src={thumb} alt="" className="h-16 w-16 rounded-xl bg-paper object-cover" />
                                <div className="min-w-0 flex-1">
                                  <p className="text-sm font-bold">{i.name}</p>
                                  <p className="text-xs text-ink/50">
                                    {i.color}{i.size && i.size !== "Unique" ? ` · Taille ${i.size}` : ""} · {i.qty ?? i.totalQty} unité(s)
                                  </p>
                                  <p className="text-xs text-ink/50">
                                    {i.placements?.side === "inclus"
                                      ? "Logo inclus"
                                      : [
                                          i.placements?.front ? `Logo devant (${POS_LABEL[i.placements.position] || "auto"})` : null,
                                          i.placements?.back ? "dos" : null,
                                        ].filter(Boolean).join(" + ")}
                                  </p>
                                  <p className="mt-1 text-sm font-extrabold">{fmt(i.lineTotal)}</p>
                                </div>
                                <button
                                  onClick={() => onRemove(i.key)}
                                  aria-label="Retirer cet item"
                                  className="self-start rounded-full p-1.5 text-ink/30 transition hover:bg-red-50 hover:text-red-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                                >
                                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
                                </button>
                              </motion.div>
                            );
                          })}
                        </AnimatePresence>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  <motion.div
                    key="etape-infos"
                    custom={stepDir.current}
                    variants={stepVariants}
                    initial="enter"
                    animate="center"
                    exit="exit"
                    className="w-full space-y-3"
                  >
                    {logo && (
                      <div className="flex items-center gap-3 rounded-2xl bg-paper p-3">
                        <img src={logo} alt="" className="h-10 w-10 rounded-lg bg-white object-contain p-1" />
                        <p className="text-xs text-ink/55">
                          Logo <span className="font-semibold">{logoName || "importé"}</span>, vectorisé et joint à la commande
                        </p>
                      </div>
                    )}
                    <Field label="Nom de l'entreprise *" value={form.company} onChange={set("company")} autoComplete="organization" />
                    <Field label="Personne contact *" value={form.contact} onChange={set("contact")} autoComplete="name" />
                    <Field
                      label="Courriel *" type="email" value={form.email} onChange={set("email")}
                      onBlur={markTouched("email")} error={emailError} autoComplete="email"
                    />
                    <Field
                      label="Téléphone *" type="tel" value={form.phone} onChange={set("phone")}
                      onBlur={markTouched("phone")} error={phoneError} autoComplete="tel" inputMode="tel"
                    />
                    <Field label="Adresse de livraison *" value={form.address} onChange={set("address")} autoComplete="street-address" />
                    <div className="grid grid-cols-2 gap-3">
                      <Field label="Ville *" value={form.city} onChange={set("city")} autoComplete="address-level2" />
                      <Field label="Code postal" value={form.postal} onChange={set("postal")} autoComplete="postal-code" />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-bold text-ink/55">Notes (couleurs Pantone, détails…)</label>
                      <textarea
                        value={form.notes} onChange={set("notes")} rows={3}
                        className="w-full rounded-xl border border-ink/10 bg-paper px-3 py-2 text-sm outline-none transition focus:border-brand-500 focus:bg-white"
                      />
                    </div>
                    <label className={`flex cursor-pointer items-start gap-3 rounded-2xl bg-paper p-3.5 transition ${policyOk ? "" : "ring-1 ring-inset ring-ink/10"}`}>
                      <input
                        type="checkbox"
                        checked={policyOk}
                        onChange={(e) => setPolicyOk(e.target.checked)}
                        className="mt-0.5 h-4 w-4 shrink-0 accent-brand-600"
                      />
                      <span className="text-[11px] leading-snug text-ink/60">
                        J&rsquo;accepte que mon logo soit retravaillé (position, taille, qualité) selon les normes
                        d&rsquo;impression textile, et que ma commande personnalisée soit{" "}
                        <span className="font-bold text-ink/80">non remboursable</span>, sauf en cas d&rsquo;erreur de
                        production de notre part.
                      </span>
                    </label>
                    {error && (
                      <div role="alert" className="flex items-start gap-2.5 rounded-2xl bg-red-50 p-3.5">
                        <svg className="mt-0.5 shrink-0 text-red-500" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                        <div className="text-red-700">
                          <p className="text-sm font-bold">La commande n&rsquo;a pas été envoyée</p>
                          <p className="mt-0.5 text-xs leading-snug">{error}</p>
                        </div>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="p-5 shadow-[0_-6px_20px_rgba(11,15,13,0.05)]">
              {discountPct > 0 && subtotal > 0 && (
                <div className="mb-1.5 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-1.5 font-bold text-brand-700">
                    🎯 Rabais jeu de la taupe ({discountPct} %)
                  </span>
                  <span className="font-bold text-brand-700">−<Amount value={rebate} /></span>
                </div>
              )}
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-ink/50">Total (avant taxes)</span>
                <Amount value={total} className="font-display text-2xl font-extrabold" />
              </div>
              {step === "cart" ? (
                <button
                  onClick={goToForm}
                  disabled={items.length === 0}
                  className="w-full rounded-full bg-brand-600 py-4 text-sm font-bold text-white shadow-soft transition-all enabled:hover:bg-brand-500 enabled:hover:shadow-lift disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-700 focus-visible:ring-offset-2"
                >
                  Passer la commande →
                </button>
              ) : (
                <>
                  <div className="flex gap-2">
                    <button
                      onClick={backToCart}
                      aria-label="Retour au panier"
                      className="rounded-full px-5 py-4 text-sm font-semibold text-ink/55 transition hover:bg-paper focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
                    >
                      ←
                    </button>
                    <button
                      onClick={submit}
                      disabled={!formValid || step === "sending"}
                      aria-busy={step === "sending"}
                      className="flex-1 rounded-full bg-brand-600 py-4 text-sm font-bold text-white shadow-soft transition-all enabled:hover:bg-brand-500 disabled:opacity-40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand-700 focus-visible:ring-offset-2"
                    >
                      <span className="inline-flex items-center justify-center gap-2">
                        {step === "sending" && <Spinner reduceMotion={reduceMotion} />}
                        {step === "sending" ? "Envoi en cours…" : "Confirmer et payer"}
                      </span>
                    </button>
                  </div>
                  {step === "form" && blocker && (
                    <p className={`mt-2 text-center text-[11px] font-semibold ${blocker.warn ? "text-amber-700" : "text-ink/45"}`}>
                      {blocker.msg}
                    </p>
                  )}
                </>
              )}
              <p className="mt-3 text-center text-xs text-ink/40">Production en 5 jours ouvrables après confirmation</p>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function Field({ label, value, onChange, onBlur, type = "text", error = "", autoComplete, inputMode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-bold text-ink/55">{label}</label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        autoComplete={autoComplete}
        inputMode={inputMode}
        aria-invalid={!!error}
        className={`w-full rounded-xl border bg-paper px-3 py-2.5 text-sm outline-none transition focus:bg-white ${
          error ? "border-red-300 focus:border-red-500" : "border-ink/10 focus:border-brand-500"
        }`}
      />
      <AnimatePresence initial={false}>
        {error && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.18 }}
            className="overflow-hidden text-[11px] font-semibold leading-snug text-red-600"
          >
            <span className="block pt-1">{error}</span>
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
