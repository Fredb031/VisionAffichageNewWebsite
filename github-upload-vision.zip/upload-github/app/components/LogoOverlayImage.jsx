

import { useEffect, useRef, useState } from "react";
import { placement, productImage } from "~/lib/catalog";
import { luminance } from "~/lib/colors";

/**
 * Image produit avec le logo du client rendu comme une VRAIE impression DTF :
 * le logo est composité sur le tissu — les plis et ombres du vêtement traversent
 * l'impression, et le rendu s'adapte à la couleur du tissu (sous-couche blanche
 * simulée sur les tissus foncés).
 */

// Cache de décodage : les mêmes visuels (vêtement, variations de logo) reviennent
// constamment pendant la personnalisation ; on ne les redécode pas à chaque rendu.
const IMG_CACHE = new Map();

function getImage(src) {
  const hit = IMG_CACHE.get(src);
  if (hit) return hit;
  const p = new Promise((resolve, reject) => {
    const im = new Image();
    im.decoding = "async";
    im.onload = () => resolve(im);
    im.onerror = () => {
      IMG_CACHE.delete(src); // ne pas mettre en cache un échec
      reject(new Error("image load failed"));
    };
    im.src = src;
  });
  if (IMG_CACHE.size > 48) IMG_CACHE.clear(); // garde-fou mémoire (dataURLs volumineux)
  IMG_CACHE.set(src, p);
  return p;
}

export default function LogoOverlayImage({
  product,
  logo,
  color = null,
  view = "front",
  position = "coeur-gauche",
  scale = 1,
  className = "",
  showBack = false,
}) {
  const img = productImage(product, color, view);
  const place = logo ? placement(product, { position, view, scale }) : null;
  const showLogo = place && (view !== "back" || showBack);

  // Tissu foncé ? (décide du mode de fusion — DTF a une sous-couche blanche)
  const darkFabric = color ? luminance(color) < 100 : true;

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <img src={img} alt={product.name} className="h-full w-full object-cover" loading="lazy" draggable={false} />
      {showLogo && (
        <PrintedLogo
          garmentSrc={img}
          logoSrc={logo}
          place={place}
          dark={darkFabric}
          maxHFrac={(view === "back" ? 0.3 : 0.22) * scale}
        />
      )}
    </div>
  );
}

/**
 * Composite le logo sur le tissu en canvas :
 * 1. logo dessiné avec bords adoucis (encre DTF)
 * 2. les ombres/plis du vêtement sont fusionnés PAR-DESSUS le logo
 *    (multiply sur tissu pâle, soft-light sur tissu foncé)
 * 3. re-découpe sur la forme exacte du logo
 * Le composant reste monté : les changements de position/taille glissent en douceur
 * (transition CSS) au lieu de re-flasher, et le canvas est redessiné au besoin.
 */
function PrintedLogo({ garmentSrc, logoSrc, place, dark, maxHFrac = 0.24 }) {
  const canvasRef = useRef(null);
  const [style, setStyle] = useState(null);
  const [fallback, setFallback] = useState(false);

  useEffect(() => {
    let cancelled = false;
    Promise.all([getImage(garmentSrc), getImage(logoSrc)])
      .then(([garment, logoImg]) => {
        if (cancelled) return;
        const canvas = canvasRef.current;
        if (!canvas) return;
        try {
          const gw = garment.naturalWidth || 1024;
          const gh = garment.naturalHeight || 1024;
          // SVG sans attributs width/height : naturalWidth peut valoir 0 → ratio 1, sans planter
          const lw = logoImg.naturalWidth;
          const lh = logoImg.naturalHeight;
          const aspect = lw > 0 && lh > 0 ? lh / lw : 1;

          // Rect du logo en coordonnées du vêtement
          let w = (parseFloat(place.width) / 100) * gw;
          let h = w * aspect;
          // Garde-fou proportionnel à la manivelle — chaque % du slider reste visible
          const maxH = gh * maxHFrac;
          if (h > maxH) { const r = maxH / h; h = maxH; w *= r; }

          const cx = (parseFloat(place.left) / 100) * gw;
          const ty = (parseFloat(place.top) / 100) * gh;
          const sx = cx - w / 2;

          // Backing store multiplié par le devicePixelRatio (plafonné à x2)
          // pour un rendu net sur écrans Retina sans exploser la mémoire
          const dpr = Math.min(2, (typeof window !== "undefined" && window.devicePixelRatio) || 1);
          const bw = Math.max(2, Math.round(w * dpr));
          const bh = Math.max(2, Math.round(h * dpr));
          if (canvas.width !== bw) canvas.width = bw;
          if (canvas.height !== bh) canvas.height = bh;
          const ctx = canvas.getContext("2d");
          ctx.clearRect(0, 0, bw, bh);

          // 1. L'encre : logo aux bords adoucis, l'encre épouse le tissu
          ctx.filter = `blur(${(0.5 * dpr).toFixed(2)}px) saturate(0.95)`;
          ctx.drawImage(logoImg, 0, 0, bw, bh);
          ctx.filter = "none";

          // 2. Le tissu traverse l'impression : plis, ombres ET reflets du molleton
          const fabric = () => ctx.drawImage(garment, sx, ty, w, h, 0, 0, bw, bh);
          if (dark) {
            // Tissu foncé (sous-couche blanche DTF) : relief marqué + reflets des plis
            ctx.globalCompositeOperation = "soft-light"; ctx.globalAlpha = 0.8; fabric();
            ctx.globalCompositeOperation = "multiply"; ctx.globalAlpha = 0.28; fabric();
            ctx.globalCompositeOperation = "screen"; ctx.globalAlpha = 0.16; fabric();
          } else {
            // Tissu pâle : les ombres des plis s'impriment dans l'encre + reflets doux
            ctx.globalCompositeOperation = "multiply"; ctx.globalAlpha = 0.92; fabric();
            ctx.globalCompositeOperation = "overlay"; ctx.globalAlpha = 0.3; fabric();
          }

          // 3. Re-découpe sur la forme exacte du logo, encre à 97 % (mat DTF)
          ctx.globalAlpha = 1;
          ctx.globalCompositeOperation = "destination-in";
          ctx.drawImage(logoImg, 0, 0, bw, bh);
          ctx.globalCompositeOperation = "source-over";

          // Position CSS (en % du conteneur) — mise à jour seulement si elle change
          const next = {
            top: `${(ty / gh) * 100}%`,
            left: `${(sx / gw) * 100}%`,
            width: `${(w / gw) * 100}%`,
          };
          setStyle((prev) =>
            prev && prev.top === next.top && prev.left === next.left && prev.width === next.width
              ? prev
              : next
          );
          setFallback((f) => (f ? false : f));
        } catch {
          setFallback(true);
        }
      })
      .catch(() => { if (!cancelled) setFallback(true); });
    return () => { cancelled = true; };
  }, [garmentSrc, logoSrc, place.top, place.left, place.width, dark, maxHFrac]);

  return (
    <>
      {fallback && (
        // Filet de sécurité : superposition simple (le navigateur sait afficher
        // un SVG sans dimensions dans un <img>)
        <img
          src={logoSrc}
          alt=""
          className="absolute object-contain"
          style={{
            top: place.top, left: place.left, width: place.width, maxHeight: "22%",
            transform: "translateX(-50%)", mixBlendMode: dark ? "normal" : "multiply", opacity: 0.96,
          }}
          draggable={false}
        />
      )}
      <canvas
        ref={canvasRef}
        className="absolute transition-all duration-300 ease-out"
        style={
          fallback
            ? { display: "none" }
            : style
            ? { ...style, opacity: 0.97, filter: "drop-shadow(0 0.4px 0.5px rgba(0,0,0,0.14))" }
            : { opacity: 0 }
        }
      />
    </>
  );
}
