import {Link} from 'react-router';

export async function loader() {
  throw new Response('Page introuvable', {status: 404});
}

export default function CatchAll() {
  return null;
}

export function ErrorBoundary() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-3 bg-paper font-display text-ink">
      <h1 className="text-4xl font-extrabold">404</h1>
      <p className="text-ink/60">Cette page n'existe pas.</p>
      <Link to="/" className="font-bold text-brand-600">
        Retour à l'accueil
      </Link>
    </main>
  );
}
