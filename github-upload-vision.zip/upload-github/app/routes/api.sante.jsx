import {shopifyConfigured} from '~/lib/shopifyDraft.server';

/** Bilan de santé (booléens seulement, aucun secret). */
export async function loader({context}) {
  const env = context.env;
  return new Response(
    JSON.stringify({
      plateforme: 'hydrogen-oxygen',
      boutique: env.PUBLIC_STORE_DOMAIN || null,
      checkout_shopify: shopifyConfigured(env),
    }),
    {headers: {'Content-Type': 'application/json'}},
  );
}
