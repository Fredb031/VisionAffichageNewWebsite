import {getProduct, unitPrice, isPack, LOGO_FRONT_PRICE, LOGO_BACK_PRICE} from '~/lib/catalog';
import {
  shopifyConfigured,
  createShopifyDraft,
  uploadLogos,
} from '~/lib/shopifyDraft.server';

const MAX_BODY_CHARS = 10_000_000;
const MAX_ITEMS = 100;
const MAX_QTY = 10_000;
const MAX_UNIT_PRICE = 100_000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const json = (obj, init) =>
  new Response(JSON.stringify(obj), {
    ...init,
    headers: {'Content-Type': 'application/json', ...(init?.headers || {})},
  });

function orderNumber() {
  const d = new Date();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `VA-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(
    d.getDate(),
  ).padStart(2, '0')}-${rand}`;
}

/* Limite simple : 8 commandes / 10 minutes par IP (mémoire de l'isolate) */
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const windowMs = 10 * 60 * 1000;
  const arr = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 2000) hits.clear();
  return arr.length > 8;
}

/** Valide le panier. Retourne un message d'erreur français, ou null. */
function validateItems(items) {
  if (!Array.isArray(items) || items.length === 0) return 'Ton panier est vide.';
  if (items.length > MAX_ITEMS) {
    return `Trop d'articles dans la commande (maximum ${MAX_ITEMS}).`;
  }
  for (let idx = 0; idx < items.length; idx++) {
    const i = items[idx];
    const label = `Article ${idx + 1}`;
    if (!i || typeof i !== 'object' || Array.isArray(i)) return `${label} : format invalide.`;
    if (typeof i.name !== 'string' || !i.name.trim() || i.name.length > 200) {
      return `${label} : nom de produit manquant ou invalide.`;
    }
    const name = i.name.trim();
    const qty = i.qty || i.totalQty;
    if (typeof qty !== 'number' || !Number.isInteger(qty) || qty <= 0 || qty >= MAX_QTY) {
      return `${label} (${name}) : quantité invalide.`;
    }
    if (
      typeof i.unitPrice !== 'number' ||
      !Number.isFinite(i.unitPrice) ||
      i.unitPrice <= 0 ||
      i.unitPrice > MAX_UNIT_PRICE
    ) {
      return `${label} (${name}) : prix unitaire invalide.`;
    }
    if (typeof i.lineTotal !== 'number' || !Number.isFinite(i.lineTotal) || i.lineTotal <= 0) {
      return `${label} (${name}) : total de ligne invalide.`;
    }
    if (Math.abs(i.unitPrice * qty - i.lineTotal) > 0.02 * qty + 0.05) {
      return `${label} (${name}) : le total de ligne ne correspond pas. Recharge la page et réessaie.`;
    }
    // Vérification contre le vrai catalogue : impossible de manipuler les prix
    const product = getProduct(i.productId);
    if (!product) return `${label} (${name}) : produit inconnu. Recharge la page.`;
    const fee = isPack(product)
      ? 0
      : (i.placements?.front ? LOGO_FRONT_PRICE : 0) +
        (i.placements?.back ? LOGO_BACK_PRICE : 0);
    const expected = unitPrice(product, i.color) + fee;
    if (Math.abs(i.unitPrice - expected) > 0.005) {
      return `${label} (${name}) : le prix ne correspond plus au catalogue. Recharge la page et réessaie.`;
    }
  }
  return null;
}

export async function loader() {
  return json({error: 'Méthode non permise.'}, {status: 405});
}

export async function action({request, context}) {
  const env = context.env;
  const ip = request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'inconnu';
  if (rateLimited(ip)) {
    return json(
      {error: "Trop de commandes d'affilée. Réessaie dans quelques minutes."},
      {status: 429},
    );
  }

  let body;
  try {
    const raw = await request.text();
    if (raw.length > MAX_BODY_CHARS) {
      return json(
        {error: 'Commande trop volumineuse. Réduis la taille de tes logos et réessaie.'},
        {status: 413},
      );
    }
    body = JSON.parse(raw);
  } catch {
    return json({error: 'Requête invalide.'}, {status: 400});
  }

  try {
    const {customer, items, total, logo, logoName} = body || {};
    const discountPct = body?.discountPct === 10 ? 10 : 0;

    if (!customer || typeof customer !== 'object' || Array.isArray(customer)) {
      return json({error: 'Coordonnées manquantes.'}, {status: 400});
    }
    const company = String(customer.company || '').trim().slice(0, 200);
    const email = String(customer.email || '').trim().toLowerCase().slice(0, 200);
    if (!company) return json({error: "Le nom de ton entreprise est requis."}, {status: 400});
    if (!EMAIL_RE.test(email)) return json({error: 'Entre un courriel valide.'}, {status: 400});
    customer.company = company;
    customer.email = email;

    const itemError = validateItems(items);
    if (itemError) return json({error: itemError}, {status: 400});

    const serverSubtotal = items.reduce((a, i) => a + Number(i.lineTotal || 0), 0);
    const serverTotal = +(serverSubtotal * (1 - discountPct / 100)).toFixed(2);
    if (!Number.isFinite(Number(total)) || Math.abs(serverTotal - Number(total)) > 0.05) {
      return json(
        {error: 'Le total ne balance pas. Recharge la page et réessaie.'},
        {status: 400},
      );
    }

    const num = orderNumber();

    if (!shopifyConfigured(env)) {
      // Pas encore branché : la commande est confirmée sans paiement en ligne
      return json({orderNumber: num});
    }

    // Logos utilisés → Fichiers Shopify (best effort, jamais bloquant)
    const logos = [];
    if (typeof logo === 'string' && logo.startsWith('data:image/')) {
      logos.push({name: logoName || 'logo-principal', data: logo});
    }
    if (body.logos && typeof body.logos === 'object' && !Array.isArray(body.logos)) {
      for (const [name, data] of Object.entries(body.logos)) {
        if (typeof data === 'string' && data.startsWith('data:image/')) {
          logos.push({name, data});
        }
      }
    }
    const logoFileNames = logos.length ? await uploadLogos(env, num, logos) : [];

    const draft = await createShopifyDraft(env, {
      num,
      customer,
      items,
      discountPct,
      logoFileNames,
    });

    return json({orderNumber: num, checkoutUrl: draft.invoiceUrl, shopify: draft.name});
  } catch (e) {
    console.error('POST /commander:', e);
    return json({error: 'Erreur serveur. Réessaie ou contacte-nous.'}, {status: 500});
  }
}
