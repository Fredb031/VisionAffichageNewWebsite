import {useSearchParams, Link} from 'react-router';

export function meta() {
  return [{title: 'Merci · Vision Affichage'}];
}

export default function Merci() {
  const [params] = useSearchParams();
  const order = params.get('order');

  return (
    <main className="flex min-h-screen items-center justify-center bg-paper px-6">
      <div className="w-full max-w-md rounded-[2rem] bg-white p-10 text-center shadow-lift">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-100 text-2xl">
          ✓
        </div>
        <h1 className="mt-5 font-display text-2xl font-extrabold tracking-tight">
          Commande reçue!
        </h1>
        {order && (
          <p className="mt-2 text-sm text-ink/60">
            Numéro de commande : <span className="font-bold text-ink">{order}</span>
          </p>
        )}
        <p className="mt-3 text-sm leading-relaxed text-ink/60">
          On prépare ta soumission et on te revient par courriel. Ton logo est
          retravaillé selon les normes d'impression textile avant la production.
        </p>
        <Link
          to="/produits"
          className="mt-6 inline-block rounded-full bg-ink px-8 py-3 text-sm font-bold text-white transition hover:bg-ink/80"
        >
          Retour à la boutique
        </Link>
      </div>
    </main>
  );
}
