

import { forwardRef, memo, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { colorHex, isLight } from "~/lib/colors";
import { useNavigate } from "react-router";
import {
  motion,
  AnimatePresence,
  MotionConfig,
  useReducedMotion,
  useScroll,
  useTransform,
} from "framer-motion";
import LogoOverlayImage from "~/components/LogoOverlayImage";
import ProductModal from "~/components/ProductModal";
import CartDrawer from "~/components/CartDrawer";
import MoleGame from "~/components/MoleGame";
import { PRODUCTS, fmt, hasGeneratedColors, smartDefaultColor, smartColors, minPrice } from "~/lib/catalog";

/* Easing commun (même courbe que la landing) */
const EASE = [0.22, 1, 0.36, 1];

/* Springs calibrés : une seule source de vérité pour toute la page.
   UI : réactif, léger dépassement. SOFT : grands blocs, plus moelleux.
   LAYOUT : réagencement de la grille, glisse ferme sans rebond. */
const SPRING_UI = { type: "spring", stiffness: 260, damping: 26 };
const SPRING_SOFT = { type: "spring", stiffness: 130, damping: 21, mass: 0.9 };
const SPRING_LAYOUT = { type: "spring", stiffness: 260, damping: 30 };
const SPRING_IMAGE = { type: "spring", stiffness: 170, damping: 22 };

/* Chorégraphie d'entrée : un parent orchestre (header, titre, preuves, filtres),
   les enfants suivent via variants imbriqués + staggerChildren.
   Zéro delay magique éparpillé : tout le timing vit ici. */
const pageV = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
};
const headerV = {
  hidden: { opacity: 0, y: -14 },
  show: {
    opacity: 1,
    y: 0,
    transition: { ...SPRING_SOFT, staggerChildren: 0.08, delayChildren: 0.05 },
  },
};
const groupV = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const blockV = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: SPRING_SOFT },
};
const itemV = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: SPRING_UI },
};
const popV = {
  hidden: { opacity: 0, scale: 0.6 },
  show: { opacity: 1, scale: 1, transition: SPRING_UI },
};
const slideV = {
  hidden: { opacity: 0, x: -10 },
  show: { opacity: 1, x: 0, transition: SPRING_UI },
};
const introV = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const underlineV = {
  hidden: { scaleX: 0 },
  show: { scaleX: 1, transition: { duration: 0.5, delay: 0.25, ease: EASE } },
};
const proofsV = { hidden: {}, show: { transition: { staggerChildren: 0.09 } } };
const proofItemV = {
  hidden: { opacity: 0, x: -10 },
  show: { opacity: 1, x: 0, transition: SPRING_UI },
};
const sepV = {
  hidden: { opacity: 0, scaleY: 0 },
  show: { opacity: 1, scaleY: 1, transition: SPRING_UI },
};
const starsV = { hidden: {}, show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } } };
const starV = {
  hidden: { opacity: 0, scale: 0, rotate: -60 },
  show: { opacity: 1, scale: 1, rotate: 0, transition: { type: "spring", stiffness: 400, damping: 12 } },
};
const chipsV = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };

/* Cartes : cascade au scroll (whileInView, once), sortie éclair quand le filtre
   change (popLayout retire la carte du flux), lift au hover. Transform et opacity
   seulement, jamais de propriété de layout coûteuse. */
const cardV = {
  hidden: { opacity: 0, y: 28, scale: 0.97 },
  show: (i) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { ...SPRING_SOFT, delay: 0.1 + (i % 4) * 0.07 },
  }),
  exit: { opacity: 0, scale: 0.95, transition: { duration: 0.18, ease: "easeOut" } },
  hover: { y: -6, transition: SPRING_UI },
};
const cardShadowV = { hover: { opacity: 1 } };

/* Carte produit : au survol (ou au focus clavier), le morceau se retourne pour montrer le dos.
   Mémoïsée : le tick du mot rotatif et le panier ne re-rendent plus la grille.
   forwardRef : requis par AnimatePresence mode="popLayout" pour mesurer la carte sortante.
   Le dos est monté paresseusement au premier survol (on respecte le cache d'images),
   puis reste monté : les flips suivants sont un pur crossfade compositor. */
const ProductCard = memo(
  forwardRef(function ProductCard({ product: p, idx, logo, logoTone, onSelect }, ref) {
    const [hovered, setHovered] = useState(false);
    const [backReady, setBackReady] = useState(false);
    const canFlip = hasGeneratedColors(p) || !!p.imageBack;
    const showBackView = hovered && canFlip;
    const cardColor = hasGeneratedColors(p) ? smartDefaultColor(p, logoTone) : null;
    const dots = p.colors.length > 1 ? smartColors(p, logoTone).slice(0, 6) : [];

    const activate = () => {
      setHovered(true);
      if (canFlip) setBackReady(true);
    };
    const deactivate = () => setHovered(false);

    return (
      <motion.div
        ref={ref}
        layout
        custom={idx}
        variants={cardV}
        initial="hidden"
        whileInView="show"
        exit="exit"
        whileHover="hover"
        viewport={{ once: true, margin: "0px 0px -60px 0px" }}
        transition={{ layout: SPRING_LAYOUT }}
        className="relative"
      >
        {/* Ombre progressive : on anime l'opacité d'un calque, jamais box-shadow */}
        <motion.div
          aria-hidden="true"
          variants={cardShadowV}
          style={{ opacity: 0 }}
          transition={{ duration: 0.45, ease: EASE }}
          className="pointer-events-none absolute inset-0 rounded-3xl shadow-lift"
        />
        <motion.button
          type="button"
          whileTap={{ scale: 0.98 }}
          transition={SPRING_UI}
          onClick={() => onSelect(p)}
          onMouseEnter={activate}
          onMouseLeave={deactivate}
          onFocus={activate}
          onBlur={deactivate}
          className="relative h-full w-full overflow-hidden rounded-3xl bg-white text-left shadow-soft"
        >
          <div className="relative overflow-hidden" style={{ perspective: 1000 }}>
            {/* Zoom plush + légère bascule 3D pendant le flip */}
            <motion.div
              animate={{ scale: hovered ? 1.05 : 1, rotateY: showBackView ? -6 : 0 }}
              transition={SPRING_IMAGE}
            >
              <LogoOverlayImage
                product={p}
                logo={p.category === "pack" ? null : logo}
                color={cardColor}
                view="front"
                showBack
                className="aspect-square bg-white"
              />
              {canFlip && backReady && (
                <motion.div
                  className="absolute inset-0"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: showBackView ? 1 : 0 }}
                  transition={{ duration: 0.3, ease: EASE }}
                >
                  <LogoOverlayImage
                    product={p}
                    logo={p.category === "pack" ? null : logo}
                    color={cardColor}
                    view="back"
                    showBack
                    className="aspect-square bg-white"
                  />
                </motion.div>
              )}
            </motion.div>
            {hasGeneratedColors(p) && (
              <AnimatePresence mode="wait" initial={false}>
                <motion.span
                  key={showBackView ? "dos" : "apercu"}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.16, ease: "easeOut" }}
                  className="absolute left-3 top-3 rounded-full bg-brand-600 px-2.5 py-1 text-[10px] font-black uppercase tracking-wide text-white shadow-soft"
                >
                  {showBackView ? "Dos" : "Aperçu réel"}
                </motion.span>
              </AnimatePresence>
            )}
            {canFlip && (
              <motion.span
                initial={false}
                animate={hovered ? { opacity: 1, y: 0 } : { opacity: 0, y: 6 }}
                transition={SPRING_UI}
                className="absolute bottom-3 right-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold text-ink/50 shadow-soft backdrop-blur"
              >
                {showBackView ? "← devant" : "voir le dos →"}
              </motion.span>
            )}
          </div>
          <div className="p-4">
            <p className="font-display font-bold leading-tight">{p.name}</p>
            <div className="mt-1.5 flex items-center gap-1">
              {dots.map((c) => (
                <span
                  key={c}
                  aria-hidden="true"
                  className={`h-3 w-3 rounded-full ${isLight(c) ? "shadow-[inset_0_0_0_1px_rgba(11,15,13,0.12)]" : ""}`}
                  style={{ background: colorHex(c) }}
                />
              ))}
              {p.colors.length > 6 && (
                <span className="ml-0.5 text-[10px] font-bold text-ink/40">+{p.colors.length - 6}</span>
              )}
              {p.colors.length <= 1 && <span className="text-[11px] text-ink/40">{p.audience}</span>}
            </div>
            <div className="mt-2 flex items-center justify-between">
              <p className="text-sm font-extrabold">
                {p.category === "pack" ? fmt(p.price) : <>dès {fmt(minPrice(p))}</>}
              </p>
              <motion.span
                initial={false}
                animate={hovered ? { opacity: 1, x: 0 } : { opacity: 0, x: 8 }}
                transition={SPRING_UI}
                className="rounded-full bg-brand-50 px-3 py-1 text-xs font-bold text-brand-700"
              >
                Personnaliser →
              </motion.span>
            </div>
          </div>
        </motion.button>
      </motion.div>
    );
  })
);

const VA_LOGO = "https://visionaffichage.com/cdn/shop/files/Asset_1_d5d82510-0b83-4657-91b7-3ac1992ee697.svg";

const CATS = [
  { id: "tous", label: "Tout" },
  { id: "tshirt", label: "T-shirts" },
  { id: "hoodie", label: "Hoodies" },
  { id: "polo", label: "Polos" },
  { id: "casquette", label: "Casquettes" },
  { id: "tuque", label: "Tuques" },
  { id: "pack", label: "Packs" },
];

const ROTATING = ["hoodie", "t-shirt", "polo", "casquette", "crewneck", "tuque"];

/* Dégradé par lettre (brand-700 → brand-400) : l'effet d'un dégradé continu,
   sans bg-clip-text sur des lettres en mouvement (source classique de glitchs). */
const GRAD_FROM = [4, 118, 71];
const GRAD_TO = [56, 205, 135];
function letterColor(i, n) {
  const t = n <= 1 ? 0 : i / (n - 1);
  const c = GRAD_FROM.map((f, k) => Math.round(f + (GRAD_TO[k] - f) * t));
  return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
}

/**
 * Machine à mots premium :
 * - la fente GLISSE vers la largeur du nouveau mot (animation de layout, spring),
 *   le point et le reste de la phrase suivent en douceur au lieu de sauter;
 * - le nouveau mot entre lettre par lettre (montée + net progressif),
 *   l'ancien s'élève et se dissout PAR-DESSUS (popLayout : aucun trou entre deux mots);
 * - soulignement redessiné de gauche à droite à chaque mot;
 * - pause au survol, respecte « réduire les animations ».
 */
function RotatingWord({ words, interval = 2600 }) {
  const reduced = useReducedMotion();
  const [idx, setIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const word = words[idx];

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % words.length), interval);
    return () => clearInterval(t);
  }, [paused, words.length, interval]);

  return (
    <motion.span
      layout
      transition={{ layout: { type: "spring", stiffness: 300, damping: 32 } }}
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
      className="relative inline-block whitespace-nowrap align-baseline"
    >
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={word}
          layout="position"
          className="inline-flex whitespace-pre"
          exit={
            reduced
              ? { opacity: 0, transition: { duration: 0.15 } }
              : {
                  y: "-0.72em",
                  opacity: 0,
                  filter: "blur(5px)",
                  transition: { duration: 0.32, ease: [0.45, 0, 0.55, 1] },
                }
          }
        >
          {word.split("").map((ch, i) => (
            <motion.span
              key={`${word}-${i}`}
              initial={
                reduced
                  ? { opacity: 0 }
                  : { y: "0.72em", opacity: 0, filter: "blur(5px)", scale: 0.92 }
              }
              animate={{ y: 0, opacity: 1, filter: "blur(0px)", scale: 1 }}
              transition={{
                delay: 0.05 + i * 0.024,
                type: "spring",
                stiffness: 560,
                damping: 32,
                mass: 0.72,
              }}
              className="inline-block"
              style={{ color: letterColor(i, word.length) }}
            >
              {ch}
            </motion.span>
          ))}
        </motion.span>
      </AnimatePresence>
      <motion.span
        key={`souligne-${word}`}
        aria-hidden="true"
        initial={reduced ? { scaleX: 1 } : { scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ delay: 0.18, duration: 0.5, ease: EASE }}
        className="absolute -bottom-1 left-0 h-[3px] w-full origin-left rounded-full bg-gradient-to-r from-brand-600 to-brand-400"
      />
    </motion.span>
  );
}

/* Compteur animé (ease-out cubique). Saute directement à la valeur finale
   si l'utilisateur préfère réduire les animations. */
function CountUp({ to, suffix = "", delay = 0, duration = 1400 }) {
  const [v, setV] = useState(0);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (reduced) { setV(to); return; }
    let raf;
    const timer = setTimeout(() => {
      const t0 = performance.now();
      const step = (t) => {
        const p = Math.min(1, (t - t0) / duration);
        setV(Math.round(to * (1 - Math.pow(1 - p, 3))));
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => { clearTimeout(timer); cancelAnimationFrame(raf); };
  }, [to, delay, duration, reduced]);
  return <span className="tabular-nums">{v.toLocaleString("fr-CA")}{suffix}</span>;
}

/* Les preuves héritent du stagger du rang parent : plus de delays à la main */
function ProofItem({ children }) {
  return (
    <motion.span variants={proofItemV} className="transition-colors hover:text-ink">
      {children}
    </motion.span>
  );
}

function Sep() {
  return <motion.span variants={sepV} className="hidden h-3 w-px bg-ink/10 sm:block" aria-hidden="true" />;
}

/* Bandeau final : entrée douce + parallax discret au scroll (useScroll + useTransform).
   Le parallax est coupé si l'utilisateur préfère réduire les animations. */
function DeliveryBanner() {
  const bannerRef = useRef(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: bannerRef, offset: ["start end", "end start"] });
  const parallaxY = useTransform(scrollYProgress, [0, 1], [26, -26]);

  return (
    <motion.div
      ref={bannerRef}
      initial={{ opacity: 0, scale: 0.96 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={SPRING_SOFT}
      style={reduced ? undefined : { y: parallaxY }}
      className="mx-auto mt-14 max-w-xl rounded-3xl bg-gradient-to-br from-brand-600 to-brand-800 p-8 text-center text-white shadow-lift"
    >
      <p className="font-display text-2xl font-extrabold">Prêt en 5 jours ouvrables.</p>
      <p className="mt-1 text-sm text-white/75">Livraison gratuite dès 300 $ · Garantie 1 an sur l&rsquo;impression</p>
    </motion.div>
  );
}

export default function Produits() {
  const navigate = useNavigate();
  const [logo, setLogo] = useState(null);
  const [logoName, setLogoName] = useState("");
  const [logoTone, setLogoTone] = useState("color");
  const [ready, setReady] = useState(false);
  const [cat, setCat] = useState("tous");
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [flash, setFlash] = useState(false);
  const flashTimer = useRef(null);

  /* Barre de filtres sticky : une sentinelle + IntersectionObserver détectent
     l'ancrage, et on fond une ombre (calque en opacité, pas de box-shadow animé) */
  const [stuck, setStuck] = useState(false);
  const sentinelRef = useRef(null);

  useEffect(() => {
    const l = localStorage.getItem("va_logo");
    if (!l) { router.replace("/"); return; }
    setLogo(l);
    setLogoName(localStorage.getItem("va_logo_name") || "");
    setLogoTone(localStorage.getItem("va_logo_tone") || "color");
    try {
      const saved = sessionStorage.getItem("va_cart");
      if (saved) setCart(JSON.parse(saved));
    } catch {}
    setReady(true);
  }, [router]);

  useEffect(() => {
    if (ready) {
      try { sessionStorage.setItem("va_cart", JSON.stringify(cart)); } catch {}
    }
  }, [cart, ready]);

  useEffect(() => {
    if (!ready) return;
    const el = sentinelRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(
      ([entry]) => setStuck(!entry.isIntersecting),
      { rootMargin: "-65px 0px 0px 0px", threshold: 0 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [ready]);

  const filtered = useMemo(
    () =>
      PRODUCTS.filter((p) => {
        if (cat === "tous") return true;
        if (cat === "hoodie") return ["hoodie", "hoodie-zip", "crewneck"].includes(p.category);
        return p.category === cat;
      }),
    [cat]
  );

  const [discount, setDiscount] = useState(0);

  useEffect(() => {
    try { setDiscount(parseInt(localStorage.getItem("va_discount") || "0") || 0); } catch {}
  }, []);

  /* Pas de timer orphelin pour le flash du panier */
  useEffect(() => () => clearTimeout(flashTimer.current), []);

  const cartQty = cart.reduce((a, i) => a + i.totalQty, 0);
  const cartTotal = cart.reduce((a, i) => a + i.lineTotal, 0);

  const addToCart = useCallback((item) => {
    setCart((c) => [...c, item]);
    setFlash(true);
    clearTimeout(flashTimer.current);
    flashTimer.current = setTimeout(() => setFlash(false), 900);
  }, []);

  /* Référence stable pour que memo(ProductCard) soit efficace */
  const handleSelect = useCallback((p) => setSelected(p), []);
  const handleWin = useCallback((pct) => setDiscount(pct), []);

  if (!ready) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-paper">
        <div role="status" className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-spin rounded-full border-[3px] border-brand-100 border-t-brand-600" aria-hidden="true" />
          <p className="text-sm font-semibold text-ink/45">On prépare ta collection…</p>
        </div>
      </main>
    );
  }

  return (
    <MotionConfig reducedMotion="user">
      <motion.main variants={pageV} initial="hidden" animate="show" className="min-h-screen bg-paper pb-32">
        {/* Header partenariat : premier temps de la séquence */}
        <motion.header variants={headerV} className="sticky top-0 z-30 bg-paper/85 shadow-[0_1px_20px_rgba(11,15,13,0.05)] backdrop-blur-xl">
          <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3.5">
            <motion.div variants={groupV} className="flex items-center gap-3.5">
              <motion.img variants={slideV} src={VA_LOGO} alt="Vision Affichage" className="h-9 w-auto" />
              <motion.span
                variants={popV}
                aria-hidden="true"
                className="font-display text-xl font-light text-ink/30"
              >
                ×
              </motion.span>
              <motion.img
                variants={slideV}
                src={logo}
                alt="Ton logo"
                className="h-9 w-auto min-w-[36px] max-w-[150px] object-contain"
              />
            </motion.div>
            <motion.div variants={itemV} className="flex items-center gap-3">
              <motion.button
                type="button"
                whileTap={{ scale: 0.96 }}
                onClick={() => navigate("/")}
                className="hidden text-xs font-semibold text-ink/45 transition-colors hover:text-ink sm:block"
              >
                Changer de logo
              </motion.button>
              <motion.button
                type="button"
                whileHover={{ scale: 1.06 }}
                whileTap={{ scale: 0.94 }}
                transition={SPRING_UI}
                onClick={() => navigate("/compte")}
                title="Mon compte"
                aria-label="Mon compte"
                className="flex h-9 w-9 items-center justify-center rounded-full bg-white text-ink/55 shadow-soft transition-colors hover:text-ink"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </motion.button>
              <motion.button
                type="button"
                animate={flash ? { scale: [1, 1.18, 1] } : { scale: 1 }}
                transition={{ duration: 0.5, ease: EASE }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setCartOpen(true)}
                aria-label={cartQty > 0 ? `Ouvrir le panier, ${cartQty} ${cartQty > 1 ? "articles" : "article"}, total ${fmt(cartTotal)}` : "Ouvrir le panier"}
                className="flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-bold text-white shadow-soft transition-colors hover:bg-ink/85"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                {cartQty > 0 ? `${cartQty} · ${fmt(cartTotal)}` : "Panier"}
              </motion.button>
            </motion.div>
          </div>
        </motion.header>

        <section className="mx-auto max-w-6xl px-5 pt-10">
          {/* Intro personnalisée : deuxième temps (kicker, titre, sous-titre en cascade) */}
          <motion.div variants={introV}>
            <motion.p variants={itemV} className="text-xs font-bold uppercase tracking-[0.2em] text-brand-600">
              Ta collection, prête à commander
            </motion.p>
            <motion.h1 variants={blockV} className="mt-2 font-display text-3xl font-extrabold tracking-tight sm:text-[2.6rem] sm:leading-tight">
              Ta marque sur chaque{" "}
              <RotatingWord words={ROTATING} />.
            </motion.h1>
            <motion.p variants={blockV} className="mt-2 max-w-lg text-ink/55">
              Chaque morceau est déjà à tes couleurs. Choisis, commande, et ton équipe le porte dans 5 jours.
            </motion.p>
          </motion.div>

          {/* Preuves : troisième temps. Étoiles en pop successif, compteurs conservés */}
          <motion.div variants={proofsV} className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-[12.5px] font-semibold text-ink/50">
            <motion.span variants={proofItemV} className="flex items-center gap-1.5 transition-colors hover:text-ink">
              <motion.span variants={starsV} className="flex text-brand-600" aria-hidden="true">
                {[0, 1, 2, 3, 4].map((i) => (
                  <motion.span key={i} variants={starV}>
                    ★
                  </motion.span>
                ))}
              </motion.span>
              5/5 sur <CountUp to={41} delay={500} /> avis
            </motion.span>
            <Sep />
            <ProofItem>
              <span className="font-extrabold text-ink/75"><CountUp to={500} suffix="+" delay={650} /></span> entreprises équipées
            </ProofItem>
            <Sep />
            <ProofItem>
              <span className="font-extrabold text-ink/75"><CountUp to={33000} suffix="+" delay={800} /></span> produits livrés
            </ProofItem>
            <Sep />
            <ProofItem>
              <span className="font-extrabold text-ink/75">1 an</span> de garantie sur l&rsquo;impression
            </ProofItem>
          </motion.div>

          {/* Sentinelle invisible : dit à la barre sticky quand elle est ancrée */}
          <div ref={sentinelRef} aria-hidden="true" className="h-px -mb-px" />

          {/* Filtres : quatrième temps. Pastille active qui glisse (layoutId),
              ombre qui apparaît quand la barre s'ancre */}
          <motion.div variants={itemV} className="sticky top-[64px] z-20 -mx-5 mt-8 bg-paper/85 px-5 py-3 backdrop-blur-xl">
            <motion.div
              aria-hidden="true"
              initial={false}
              animate={{ opacity: stuck ? 1 : 0 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="pointer-events-none absolute inset-0 shadow-[0_14px_30px_-18px_rgba(11,15,13,0.28)]"
            />
            <motion.div variants={chipsV} className="flex gap-2 overflow-x-auto pb-0.5" role="group" aria-label="Filtrer par catégorie">
              {CATS.map((c) => {
                const active = cat === c.id;
                return (
                  <motion.button
                    key={c.id}
                    type="button"
                    variants={itemV}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setCat(c.id)}
                    aria-pressed={active}
                    className={`relative whitespace-nowrap rounded-full px-5 py-2 text-sm font-bold transition-colors duration-300 ${
                      active ? "text-white" : "bg-white text-ink/55 hover:text-ink"
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="cat-pill"
                        transition={SPRING_UI}
                        aria-hidden="true"
                        className="absolute inset-0 rounded-full bg-ink shadow-soft"
                      />
                    )}
                    <span className="relative z-10">{c.label}</span>
                  </motion.button>
                );
              })}
            </motion.div>
          </motion.div>

          {/* Grille produits : cascade au scroll, et au changement de filtre les cartes
              restantes glissent vers leur place (layout) pendant que les sortantes
              s'estompent hors flux (popLayout) */}
          <div className="relative mt-6 grid grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-3 xl:grid-cols-4">
            <AnimatePresence mode="popLayout">
              {filtered.map((p, idx) => (
                <ProductCard key={p.id} product={p} idx={idx} logo={logo} logoTone={logoTone} onSelect={handleSelect} />
              ))}
            </AnimatePresence>
          </div>

          {/* Rappel livraison */}
          <DeliveryBanner />
        </section>

        {selected && (
          <ProductModal product={selected} logo={logo} logoTone={logoTone} onClose={() => setSelected(null)} onAdd={addToCart} />
        )}

        <CartDrawer
          open={cartOpen}
          items={cart}
          logo={logo}
          logoName={logoName}
          discountPct={discount}
          onClose={() => setCartOpen(false)}
          onRemove={(key) => setCart((c) => c.filter((i) => i.key !== key))}
        />

        <MoleGame onWin={handleWin} />
      </motion.main>
    </MotionConfig>
  );
}
