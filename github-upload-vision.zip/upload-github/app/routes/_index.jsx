

import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router";
import {
  motion,
  AnimatePresence,
  MotionConfig,
  useAnimationControls,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
} from "framer-motion";
import { processLogo } from "~/lib/logoProcess";
import { FLOATERS } from "~/data/generatedImages";

/* Easing commun à toutes les entrées (même courbe partout = cohérence) */
const EASE = [0.22, 1, 0.36, 1];

const VA_LOGO = "https://visionaffichage.com/cdn/shop/files/Asset_1_d5d82510-0b83-4657-91b7-3ac1992ee697.svg";

// Vrais logos clients (depuis visionaffichage.com, à remplacer par les versions finales)
const CLIENT_LOGOS = [
  "https://visionaffichage.com/cdn/shop/files/extreme-fab-coul.png?v=1763588020&width=300",
  "https://visionaffichage.com/cdn/shop/files/Muni-Saint-Anselme-coul_2846d7c3-80a6-48da-a08b-ca99098aa62f.png?v=1763588679&width=300",
  "https://visionaffichage.com/cdn/shop/files/Sports-experts-coul.png?v=1763588020&width=300",
  "https://visionaffichage.com/cdn/shop/files/E-Turgeon-Sport-coul.png?v=1763588020&width=300",
  "https://visionaffichage.com/cdn/shop/files/Lacasse-coul.png?v=1763588020&width=300",
  "https://visionaffichage.com/cdn/shop/files/CFP-coul_0876cdef-2a96-4638-a3f3-d6b69f8d8fa0.png?v=1763588385&width=300",
  "https://visionaffichage.com/cdn/shop/files/9999.jpg?v=1769610460&width=400",
  "https://visionaffichage.com/cdn/shop/files/Uni-coul.png?v=1763588020&width=300",
  "https://visionaffichage.com/cdn/shop/files/Parc-massif-coul.png?v=1763588020&width=300",
];

const FLOAT_POS = [
  { cls: "left-[3%] top-[16%]", rot: -8, delay: 0, depth: 22 },
  { cls: "right-[4%] top-[14%]", rot: 7, delay: 0.9, depth: 34 },
  { cls: "left-[6%] bottom-[16%]", rot: 5, delay: 0.5, depth: 28 },
  { cls: "right-[5%] bottom-[18%]", rot: -6, delay: 1.4, depth: 18 },
];

/* Cascade de la carte « ready » : le contenu suit en escalier,
   l'aperçu du logo pop avec un spring satisfaisant */
const READY_STAGGER = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.05 } },
};
const READY_ITEM = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: EASE } },
};
const READY_LOGO = {
  hidden: { opacity: 0, scale: 0.55, y: 12 },
  show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 360, damping: 20, mass: 0.9 } },
};

/* Morceau flottant : parallax souris via motion values + spring (zéro re-render React).
   À la sortie de page, chaque morceau retombe en cascade (leaveDelay). */
function Floater({ f, pos, mx, my, leaveDelay }) {
  const x = useSpring(useTransform(mx, (v) => v * pos.depth), { stiffness: 55, damping: 18, mass: 0.6 });
  const y = useSpring(useTransform(my, (v) => v * pos.depth), { stiffness: 55, damping: 18, mass: 0.6 });
  return (
    <motion.div
      initial={{ opacity: 0, y: 40, rotate: pos.rot * 1.6, scale: 0.85 }}
      animate={{ opacity: 1, y: 0, rotate: pos.rot, scale: 1 }}
      exit={{ opacity: 0, y: 28, scale: 0.94, transition: { duration: 0.3, ease: EASE, delay: leaveDelay } }}
      transition={{ delay: 0.35 + pos.delay * 0.3, duration: 1.1, ease: EASE }}
      className={`absolute ${pos.cls}`}
    >
      <motion.div style={{ x, y }}>
        <div className="animate-float" style={{ animationDelay: `${pos.delay}s` }}>
          <img
            src={f.src}
            alt={f.label}
            className="h-44 w-44 object-contain drop-shadow-[0_25px_35px_rgba(11,15,13,0.16)] xl:h-52 xl:w-52"
            draggable={false}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

/* Mots du hero animés un à un. Le pb/-mb garde les descendantes (g, j) visibles
   malgré le bg-clip-text, sans changer l'espacement des lignes. */
function HeroWords({ text, baseDelay, gradient = false }) {
  return text.split(" ").map((w, i) => (
    <motion.span
      key={i}
      initial={{ opacity: 0, y: 26, rotateX: 45 }}
      animate={{ opacity: 1, y: 0, rotateX: 0 }}
      transition={{ delay: baseDelay + i * 0.09, duration: 0.7, ease: EASE }}
      className={
        gradient
          ? "-mb-[0.18em] inline-block bg-gradient-to-r from-brand-700 via-brand-500 to-brand-600 bg-clip-text pb-[0.18em] text-transparent"
          : "inline-block"
      }
    >
      {w}&nbsp;
    </motion.span>
  ));
}

export default function Landing() {
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const reduced = useReducedMotion();
  const [state, setState] = useState("idle"); // idle | processing | ready | leaving
  const [logoData, setLogoData] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState(0);
  const [pulseKey, setPulseKey] = useState(0); // onde d'absorption au drop
  const absorb = useAnimationControls(); // petit creux de la carte qui « avale » le fichier
  const leaveTimer = useRef(null);

  useEffect(() => () => clearTimeout(leaveTimer.current), []);

  /* Parallax souris : motion values partagées, aucun setState par mousemove */
  const mx = useMotionValue(0);
  const my = useMotionValue(0);

  const onMove = useCallback(
    (e) => {
      if (reduced) return;
      const { innerWidth: w, innerHeight: h } = window;
      mx.set((e.clientX / w - 0.5) * 2);
      my.set((e.clientY / h - 0.5) * 2);
    },
    [mx, my, reduced]
  );

  const handleFile = useCallback(async (file) => {
    setError("");
    if (!file) return;
    const okType = /^image\/(png|jpe?g|svg\+xml|webp)$/.test(file.type)
      || (!file.type && /\.(png|jpe?g|svg|webp)$/i.test(file.name || ""));
    if (!okType) {
      setError("Format non supporté. Utilise un PNG, JPG, SVG ou WEBP.");
      return;
    }
    if (file.size > 6 * 1024 * 1024) {
      setError("Fichier trop lourd (max 6 Mo).");
      return;
    }
    /* Absorption visuelle : la carte creuse légèrement et l'ombre pulse vers l'intérieur */
    if (!reduced) {
      setPulseKey((k) => k + 1);
      absorb.start({ scale: [1, 0.976, 1], transition: { duration: 0.5, times: [0, 0.4, 1], ease: EASE } });
    }
    setState("processing");
    setStep(1);
    const t1 = setTimeout(() => setStep(2), 700);
    const t2 = setTimeout(() => setStep(3), 1500);
    try {
      const result = await processLogo(file);
      setLogoData(result);
      setState("ready");
    } catch {
      setError("Impossible de traiter ce fichier. Essaie un autre format.");
      setState("idle");
    } finally {
      clearTimeout(t1);
      clearTimeout(t2);
    }
  }, [reduced, absorb]);

  const confirm = useCallback(() => {
    if (!logoData || state !== "ready") return;
    try {
      const finalLogo = logoData.svg || logoData.png;
      localStorage.setItem("va_logo", finalLogo);
      localStorage.setItem("va_logo_name", logoData.name);
      localStorage.setItem("va_logo_vect", logoData.vectorized ? "1" : "0");
      localStorage.setItem("va_logo_tone", logoData.tone || "color");
      // Bibliothèque de variations (compte ou invité)
      try {
        const lib = JSON.parse(localStorage.getItem("va_logos") || "[]");
        if (!lib.some((l) => l.data === finalLogo)) {
          lib.unshift({ id: Date.now(), name: logoData.name.replace(/\.[^.]+$/, ""), data: finalLogo, tone: logoData.tone || "color" });
          localStorage.setItem("va_logos", JSON.stringify(lib.slice(0, 12)));
        }
      } catch {}
      sessionStorage.removeItem("va_cart");
    } catch {
      setError("Logo trop lourd pour le navigateur. Essaie une version plus légère.");
      return;
    }
    setState("leaving");
    leaveTimer.current = setTimeout(() => navigate("/produits"), 600);
  }, [logoData, router, state]);

  return (
    <MotionConfig reducedMotion="user">
      <main onMouseMove={onMove} className="relative flex h-[100dvh] flex-col overflow-hidden bg-paper">
        {/* Fond animé */}
        <div className="pointer-events-none absolute inset-0">
          <div className="absolute -top-40 left-1/2 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-brand-300/35 blur-3xl animate-blob" />
          <div className="absolute bottom-[-200px] left-[-140px] h-[460px] w-[460px] rounded-full bg-brand-200/45 blur-3xl animate-blob" style={{ animationDelay: "-5s" }} />
          <div className="absolute right-[-160px] top-1/3 h-[400px] w-[400px] rounded-full bg-brand-400/20 blur-3xl animate-blob" style={{ animationDelay: "-9s" }} />
        </div>

        <AnimatePresence>
          {state !== "leaving" && (
            <motion.div
              exit={{ opacity: 0, transition: { duration: 0.2, delay: 0.34, ease: "easeOut" } }}
              className="relative z-10 flex min-h-0 flex-1 flex-col"
            >
              {/* Morceaux générés qui flottent (sans fond), parallax souris.
                  Dans le bloc sortant pour retomber en cascade au départ. */}
              <div className="pointer-events-none absolute inset-0 hidden lg:block">
                {FLOATERS.slice(0, 4).map((f, i) => (
                  <Floater key={i} f={f} pos={FLOAT_POS[i % FLOAT_POS.length]} mx={mx} my={my} leaveDelay={i * 0.05} />
                ))}
              </div>

              {/* Centre : logo VA + hero + upload */}
              <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col items-center justify-center px-6 text-center">
                <motion.img
                  src={VA_LOGO}
                  alt="Vision Affichage"
                  initial={{ opacity: 0, y: -12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -12, transition: { duration: 0.28, ease: EASE, delay: 0.22 } }}
                  transition={{ duration: 0.7, ease: EASE }}
                  className="mb-7 h-10 w-auto sm:h-11"
                />

                {/* Hero : 2 lignes, jamais coupées (descendantes protégées dans HeroWords).
                    À la sortie, les deux lignes décollent l'une après l'autre. */}
                <h1 className="w-full font-display font-extrabold leading-[1.2] tracking-tight">
                  <motion.span
                    exit={{ opacity: 0, y: -18, transition: { duration: 0.3, ease: EASE, delay: 0.1 } }}
                    className="block whitespace-nowrap text-[clamp(1.3rem,5vw,3.3rem)]"
                    style={{ perspective: 900 }}
                  >
                    <HeroWords text="Ton linge d'entreprise" baseDelay={0.15} />
                  </motion.span>
                  <motion.span
                    exit={{ opacity: 0, y: -18, transition: { duration: 0.3, ease: EASE, delay: 0.16 } }}
                    className="block whitespace-nowrap text-[clamp(1.3rem,5vw,3.3rem)]"
                    style={{ perspective: 900 }}
                  >
                    <HeroWords text="Livré en 5 jours ouvrables" baseDelay={0.55} gradient />
                  </motion.span>
                </h1>

                {/* Upload : une seule carte qui morphe entre idle, processing et ready.
                    La carte part en premier lors de la sortie de page. */}
                <motion.div
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -24, scale: 0.96, transition: { duration: 0.3, ease: EASE } }}
                  transition={{ delay: 0.55, duration: 0.8, ease: EASE }}
                  className="mt-7 w-full max-w-md"
                >
                  <motion.div animate={absorb} className="relative">
                    <MorphPanel
                      reduced={reduced}
                      animate={{ scale: dragging ? 1.02 : 1 }}
                      transition={{ scale: { type: "spring", stiffness: 320, damping: 24 } }}
                      whileHover={state === "idle" ? { scale: 1.015 } : undefined}
                      className={`relative overflow-hidden rounded-[1.8rem] backdrop-blur-md transition-[background-color,box-shadow] duration-300 ease-smooth ${
                        state === "idle"
                          ? dragging
                            ? "bg-brand-50/90 shadow-lift"
                            : "bg-white/80 shadow-soft hover:bg-white hover:shadow-lift"
                          : "bg-white shadow-lift"
                      }`}
                    >
                      <AnimatePresence mode="wait" initial={false}>
                        {state === "idle" && (
                          <motion.button
                            key="idle"
                            type="button"
                            initial={{ opacity: 0, y: 12, scale: 0.98 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -10, scale: 0.99, transition: { duration: 0.18, ease: EASE } }}
                            transition={{ duration: 0.28, ease: EASE, scale: { type: "spring", stiffness: 480, damping: 28 } }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => inputRef.current?.click()}
                            onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
                            onDragLeave={() => setDragging(false)}
                            onDrop={(e) => { e.preventDefault(); setDragging(false); handleFile(e.dataTransfer.files?.[0]); }}
                            aria-label="Importer ton logo (PNG, JPG, SVG ou WEBP, max 6 Mo)"
                            className="group w-full cursor-pointer rounded-[1.8rem] p-7"
                          >
                            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-soft transition-transform duration-300 ease-smooth group-hover:scale-110 group-hover:rotate-3">
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
                              </svg>
                            </div>
                            <p className="font-display text-lg font-extrabold">Importe ton logo</p>
                            <p className="mt-1 text-sm text-ink/45">Glisse-le ici ou clique · PNG, JPG, SVG, WEBP</p>
                          </motion.button>
                        )}

                        {state === "processing" && (
                          <motion.div
                            key="processing"
                            initial={{ opacity: 0, y: 12, scale: 0.98 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -10, scale: 0.99, transition: { duration: 0.18, ease: EASE } }}
                            transition={{ duration: 0.28, ease: EASE }}
                            aria-busy="true"
                            aria-live="polite"
                            className="p-7"
                          >
                            <div
                              role="status"
                              aria-label="Traitement du logo en cours"
                              className="mx-auto mb-4 h-11 w-11 animate-spin rounded-full border-[3px] border-brand-100 border-t-brand-600"
                            />
                            <ProcessStep done={step > 1} active={step === 1}>Lecture du fichier</ProcessStep>
                            <ProcessStep done={step > 2} active={step === 2}>Détourage du fond</ProcessStep>
                            <ProcessStep done={false} active={step === 3}>Optimisation vectorielle</ProcessStep>
                          </motion.div>
                        )}

                        {state === "ready" && logoData && (
                          <motion.div
                            key="ready"
                            variants={READY_STAGGER}
                            initial="hidden"
                            animate="show"
                            exit={{ opacity: 0, y: -10, transition: { duration: 0.2, ease: EASE } }}
                            className="p-6"
                          >
                            <motion.div
                              variants={READY_ITEM}
                              className="mx-auto flex h-32 w-full max-w-xs items-center justify-center rounded-2xl p-4"
                              style={{ background: "repeating-conic-gradient(#f0f1f0 0% 25%, #ffffff 0% 50%) 50% / 18px 18px" }}
                            >
                              <motion.img
                                variants={READY_LOGO}
                                src={logoData.svg || logoData.png}
                                alt="Aperçu de ton logo, fond retiré"
                                className="max-h-full max-w-full object-contain"
                              />
                            </motion.div>
                            <motion.div variants={READY_ITEM} className="mt-3 flex items-center justify-center gap-4 text-xs font-bold text-brand-700">
                              <span className="flex items-center gap-1"><Check /> Fond retiré</span>
                              {logoData.vectorized && <span className="flex items-center gap-1"><Check /> Qualité vectorielle</span>}
                            </motion.div>
                            <motion.p variants={READY_ITEM} className="mt-2.5 font-display text-lg font-extrabold">C&rsquo;est le bon logo?</motion.p>
                            <motion.div variants={READY_ITEM} className="mt-3.5 flex items-center justify-center gap-3">
                              <motion.button
                                type="button"
                                whileTap={{ scale: 0.97 }}
                                onClick={() => { setLogoData(null); setState("idle"); }}
                                className="rounded-full px-5 py-2.5 text-sm font-semibold text-ink/55 transition-colors hover:bg-paper"
                              >
                                Changer
                              </motion.button>
                              <motion.button
                                type="button"
                                whileHover={{ scale: 1.04 }}
                                whileTap={{ scale: 0.94, y: 1 }}
                                transition={{ type: "spring", stiffness: 600, damping: 30 }}
                                onClick={confirm}
                                className="rounded-full bg-brand-600 px-8 py-3 text-sm font-bold text-white shadow-soft transition-colors hover:bg-brand-500"
                              >
                                Oui, continuer →
                              </motion.button>
                            </motion.div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </MorphPanel>

                    {/* Onde d'absorption : l'ombre pulse et se resserre sur la carte au drop */}
                    {pulseKey > 0 && !reduced && (
                      <motion.div
                        key={pulseKey}
                        aria-hidden="true"
                        initial={{ opacity: 0.5, scale: 1.045 }}
                        animate={{ opacity: 0, scale: 0.99 }}
                        transition={{ duration: 0.65, ease: "easeOut" }}
                        className="pointer-events-none absolute inset-0 rounded-[1.8rem]"
                        style={{ boxShadow: "0 0 0 3px rgba(18, 183, 106, 0.45), 0 18px 44px rgba(18, 183, 106, 0.3)" }}
                      />
                    )}
                  </motion.div>

                  <input
                    ref={inputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    className="hidden"
                    aria-hidden="true"
                    tabIndex={-1}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      e.target.value = "";
                      handleFile(file);
                    }}
                  />
                  <AnimatePresence>
                    {error && (
                      <motion.p
                        key="error"
                        role="alert"
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.25, ease: EASE }}
                        className="mt-3 text-sm font-semibold text-red-600"
                      >
                        {error}
                      </motion.p>
                    )}
                  </AnimatePresence>
                </motion.div>

                {/* Entreprises clientes : cases à largeur fixe = boucle parfaite, zéro layout shift */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, transition: { duration: 0.22, ease: "easeOut" } }}
                  transition={{ delay: 1.1, duration: 1 }}
                  className="mt-8 w-full max-w-2xl"
                >
                  <p className="mb-4 text-center text-[11px] font-bold uppercase tracking-[0.25em] text-ink/40">
                    Plus de 500 entreprises nous font confiance
                  </p>
                  <div
                    aria-hidden="true"
                    className="marquee-pause relative h-14 overflow-hidden sm:h-16"
                    style={{
                      maskImage: "linear-gradient(to right, transparent, black 22%, black 78%, transparent)",
                      WebkitMaskImage: "linear-gradient(to right, transparent, black 22%, black 78%, transparent)",
                    }}
                  >
                    <div className="flex h-full w-max animate-marquee-rev items-center">
                      {[...CLIENT_LOGOS, ...CLIENT_LOGOS].map((src, i) => (
                        <div key={i} className="flex h-14 w-44 shrink-0 items-center justify-center px-5 sm:h-16">
                          <img
                            src={src}
                            alt=""
                            className="max-h-full w-auto max-w-full object-contain opacity-60 grayscale transition duration-300 hover:opacity-100 hover:grayscale-0"
                            draggable={false}
                            loading="lazy"
                            decoding="async"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </MotionConfig>
  );
}

function ProcessStep({ done, active, children }) {
  return (
    <p className={`flex items-center justify-center gap-2 py-1 text-sm font-semibold transition-colors ${done ? "text-brand-700" : active ? "text-ink" : "text-ink/30"}`}>
      {done ? <Check /> : active ? <span className="h-2 w-2 animate-pulse rounded-full bg-brand-500" /> : <span className="h-2 w-2 rounded-full bg-ink/15" />}
      {children}
    </p>
  );
}

function Check() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>
  );
}

/* Coquille à hauteur mesurée : le passage idle → processing → ready morphe en
   douceur (ResizeObserver + spring sur la hauteur), aucun saut de layout.
   L'observer est déconnecté au démontage, aucune fuite. */
function MorphPanel({ reduced, className, style, animate, transition, children, ...rest }) {
  const innerRef = useRef(null);
  const [h, setH] = useState(null);

  useEffect(() => {
    const el = innerRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      const next = el.offsetHeight;
      setH((prev) => (prev === next ? prev : next));
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const target = { ...(animate || {}) };
  if (h != null) target.height = h;

  return (
    <motion.div
      {...rest}
      animate={target}
      transition={{
        ...(transition || {}),
        height: reduced ? { duration: 0 } : { type: "spring", stiffness: 280, damping: 32, mass: 0.9 },
      }}
      className={className}
      style={style}
    >
      <div ref={innerRef}>{children}</div>
    </motion.div>
  );
}
