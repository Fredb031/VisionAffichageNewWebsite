// Visuels produits générés — flat lay merch customizer, SANS FOND (transparents)
// Higgsfield, 2026-07-17 · master noir décliné dans les 23 vraies couleurs, devant + dos
const CDN = "https://d8j0ntlcm91z4.cloudfront.net/user_364iInZJaEaezVZOpCsov94kwPs/";
const u = (ts, id) => `${CDN}hf_20260717_${ts}_${id}.png`;

export const GENERATED = {
  atcf2500: {
    masterFront: u("223428", "241e2839-803b-4395-a052-3783a134c240"), // noir flat lay, transparent
    masterBack: u("223429", "80a79565-3309-4ea7-98bd-57fbfac27302"),
    colors: {
      "Or": { front: u("223430", "de41354d-3354-45d8-b00d-378b2379651e"), back: u("223556", "77744a5a-f410-4473-859d-ec141d06e200") },
      "Gris cendré": { front: u("223432", "4c58c3fb-0dc2-4358-b03e-fb50c82566f7"), back: u("223557", "8ac68e9f-df4d-4385-bf00-6d5aacca5454") },
      "Gris Cendré Athlétique": { front: u("223433", "edfa9b9d-4262-4080-af9f-b72d6d498e35"), back: u("223559", "7693221b-68c9-4c3f-9129-bc9698327677") },
      "Caramel": { front: u("223434", "1d259a56-cfd5-4b73-946d-8f0f98af5086"), back: u("223600", "77a2e031-66f8-423a-a0e6-e4578968510e") },
      "Gris Foncé Chiné": { front: u("223442", "e04283c2-01a5-44e6-8ce6-c56e2d6611aa"), back: u("223638", "e04ce9bf-2d5e-4a79-b855-605d5c6eeebd") },
      "Marine Foncé": { front: u("223443", "e94bde90-5322-4e55-8103-c57190dc6447"), back: u("223639", "494119bf-2e2e-4c40-8b52-aaaa9ab739b0") },
      "Marine Chiné": { front: u("223444", "dcdf106d-014a-4dd2-bd83-1fcc5a1b9d2b"), back: u("223640", "a56e0eaa-86d1-4080-a4ff-3e8d9444e321") },
      "Rouge Chiné": { front: u("223446", "548fad8d-a0bf-4d0e-8f66-e7792c4e91ab"), back: u("223642", "9e73d410-4461-46d1-8ece-6c90f5e77be5") },
      "Royal Chiné": { front: u("223448", "a40aec27-9616-4357-b0bd-05de09df9488"), back: u("223643", "acff9079-f5f9-48f2-8017-065dcef58ee7") },
      "Kelly": { front: u("223449", "7670d9ca-947f-4457-8b42-cd74cce5111b"), back: u("223645", "19058ff0-65c9-43e8-b48e-afe8a0421855") },
      "Bleu Pâle": { front: u("223456", "2f69240b-5457-4b05-98bf-f1cc539e44fa"), back: u("223721", "541e9d91-b96e-4884-978a-23f13edbfc5e") },
      "Marron": { front: u("223457", "b1b62f20-2f7e-4cb1-8e78-e26f221caeed"), back: u("223722", "82da20e3-26ee-4f86-a8d4-c2d537dfd1ce") },
      "Vert Militaire": { front: u("223458", "30f2075c-9f0f-4378-9ee5-d4f1a93edc7d"), back: u("223724", "2b390c50-76ba-4a19-8296-5d0d67ee34bc") },
      "Marine": { front: u("223500", "73c4f633-1dce-4e2a-9a29-1d59e0e97c73"), back: u("223725", "92b8af74-73fc-4132-9905-9f0bd40cad4e") },
      "Avoine Chiné": { front: u("223501", "dbe2f8da-70db-4913-aa2d-f53960a863d1"), back: u("223726", "5d4f3e9d-0d5f-4ef1-8beb-875244a9bb19") },
      "Orange": { front: u("223502", "58c245e8-1ad9-4b79-a1fb-15e4f8882872"), back: u("223727", "5596bbfc-bed4-4681-bb9b-8000024406da") },
      "Mauve": { front: u("223510", "5be74429-b565-4474-8860-9f3981183633"), back: u("223801", "1b8e5e7f-9d06-4f65-8705-c239ca189c6e") },
      "Rouge": { front: u("223511", "28d1763a-01da-4357-b82c-33f8e70579f2"), back: u("223802", "4be7009f-5961-4f61-844a-21e762e08f6f") },
      "Royal": { front: u("223512", "4875b94c-1da0-4041-870c-66948258cafe"), back: u("223804", "c54b5217-b02e-4f51-b318-0978faf9b06f") },
      "Sable": { front: u("223514", "30accf1b-e24c-42aa-94d9-1d5e59e74ed3"), back: u("223805", "3bb085a5-4698-4567-8c69-30f95543dd38") },
      "Sangria": { front: u("223515", "3bd38d2a-9a90-49ee-8c22-b3c44053d5de"), back: u("223806", "61e7c9f2-8309-4f4f-933a-0fd6487dfacd") },
      "Saphir": { front: u("223553", "05fecfdf-6c14-417c-a699-79212d84554f"), back: u("223808", "747b67d9-6a20-4eb1-a9c4-af32145a98df") },
      "Blanc": { front: u("223555", "5dd442a3-5aaf-48ab-aea0-6bed01befe3f"), back: u("223836", "afd53e7f-4fb1-44d5-932f-d84ae8031b00") },
    },
  },
};

// Morceaux transparents qui flottent sur le landing
export const FLOATERS = [
  { src: u("223428", "241e2839-803b-4395-a052-3783a134c240"), label: "Hoodie Premium Noir" },
  { src: u("223449", "7670d9ca-947f-4457-8b42-cd74cce5111b"), label: "Hoodie Premium Kelly" },
  { src: u("223443", "e94bde90-5322-4e55-8103-c57190dc6447"), label: "Hoodie Premium Marine Foncé" },
  { src: u("223434", "1d259a56-cfd5-4b73-946d-8f0f98af5086"), label: "Hoodie Premium Caramel" },
];
