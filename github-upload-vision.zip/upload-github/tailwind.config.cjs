/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#ecfdf3",
          100: "#d2f9e1",
          200: "#a9f1c9",
          300: "#71e3ab",
          400: "#38cd87",
          500: "#12b76a",
          600: "#059455",
          700: "#047647",
          800: "#065d3a",
          900: "#064d31",
          950: "#022b1b",
        },
        ink: "#0b0f0d",
        paper: "#f5f6f5",
      },
      fontFamily: {
        display: ["Manrope", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "sans-serif"],
        body: ["-apple-system", "BlinkMacSystemFont", "Inter", "Segoe UI", "sans-serif"],
      },
      boxShadow: {
        soft: "0 8px 30px rgba(11,15,13,0.08)",
        lift: "0 20px 60px rgba(11,15,13,0.14)",
      },
      transitionTimingFunction: {
        smooth: "cubic-bezier(0.22, 1, 0.36, 1)",
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" },
        },
        blob: {
          "0%,100%": { transform: "translate(0,0) scale(1)" },
          "33%": { transform: "translate(40px,-30px) scale(1.08)" },
          "66%": { transform: "translate(-30px,25px) scale(0.95)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        blob: "blob 14s ease-in-out infinite",
        shimmer: "shimmer 3s linear infinite",
        marquee: "marquee 32s linear infinite",
        "marquee-rev": "marquee 22s linear infinite reverse",
      },
    },
  },
  plugins: [],
};
